import {isGeminiUrl,originPattern,safeUrl} from './core.js';

const $=id=>document.getElementById(id);
let state=null,tabs=[],adapter={},refreshing=false;
const statuses={idle:'מוכן לחיבור',reading:'קורא את העמוד',waiting:'ממתין לתשובת Gemini',manual:'ממתין לתשובה ידנית',approval:'ממתין לאישור פעולה משמעותית','site-access':'נדרשת הרשאת Chrome לאתר',acting:'מבצע את הפעולה',paused:'המשימה מושהית',permission:'נדרשת הרשאת גישה',done:'המשימה הושלמה',stopped:'המשימה נעצרה',error:'הפעולה הופסקה'};
const isActive=()=>state && !['idle','done','stopped','error'].includes(state.status);
function notice(message) { $('notice').textContent=message || ''; $('notice').hidden=!message; }
async function send(type,extra={}) {
  const reply=await chrome.runtime.sendMessage({type,...extra});
  if (!reply?.ok) throw new Error(reply?.error || 'לא התקבלה תשובה מהתוסף.');
  return reply.result;
}
function render(data) {
  state=data;
  $('status').textContent=statuses[state.status] || state.status;
  $('status').classList.toggle('busy',['reading','waiting','acting'].includes(state.status));
  $('steps').textContent=`${state.steps} / ${state.maxSteps} פעולות`;
  $('progress').style.width=`${state.status==='done'?100:state.steps/state.maxSteps*100}%`;
  for (const id of ['gemini-tab','target-tab','mode','task','start','open-gemini','save-settings']) $(id).disabled=!!isActive();
  $('stop').disabled=!isActive();
  $('clear').disabled=!!isActive();
  $('diagnose').disabled=!!isActive();
  notice(state.lastError);
  const pending=state.pending;
  $('approval').hidden=state.status!=='approval' || !pending;
  if (pending) {
    $('action-description').textContent=pending.description;
    $('action-reason').textContent=pending.reason;
    $('approval-reason').textContent=pending.approvalReason || '';
    $('action-site').textContent=state.observation?.url || '';
    const value=pending.action.text ?? pending.action.value ?? pending.action.url ?? (pending.navigationUrl || undefined);
    $('action-value').textContent=value ?? '';
    $('action-value').hidden=value===undefined;
  }
  $('site-access-card').hidden=state.status!=='site-access';
  $('site-access-url').textContent=state.status==='site-access' ? pending?.action.url || '' : '';
  $('resume-card').hidden=!['paused','permission'].includes(state.status);
  $('resume-text').textContent=state.status==='permission'?'העמוד עבר לאתר חדש. לחצי להענקת גישה לאתר ולהמשך.':'אפשר לקרוא שוב את העמוד ולבקש הוראה חדשה.';
  $('resume').disabled=state.steps>=state.maxSteps;
  $('manual-card').hidden=state.status!=='manual';
  $('retry-gemini').hidden=state.mode!=='auto';
  $('retry-hint').hidden=state.mode!=='auto';
  $('captured-reply').hidden=!state.lastReply;
  $('last-reply').value=state.lastReply || '';
  $('prompt').value=state.prompt || '';
  $('answer-card').hidden=!state.answer;
  $('answer').textContent=state.answer || '';
  const fragment=document.createDocumentFragment();
  for (const item of state.logs) {
    const li=document.createElement('li'),time=document.createElement('time'),message=document.createElement('span');
    time.textContent=new Date(item.at).toLocaleTimeString('he-IL',{hour:'2-digit',minute:'2-digit'});
    message.className='log-message'; message.textContent=item.message;
    li.append(time,message); fragment.append(li);
  }
  if (!state.logs.length) { const li=document.createElement('li'); li.className='empty-log'; li.textContent='הפעולות יופיעו כאן בזמן העבודה.'; fragment.append(li); }
  $('logs').replaceChildren(fragment); $('logs').scrollTop=$('logs').scrollHeight;
}
async function loadState(){ render(await send('GET_STATE')); }
async function refreshTabs() {
  if (refreshing) return; refreshing=true;
  try {
    tabs=await chrome.tabs.query({currentWindow:true});
    for (const [field,predicate,placeholder] of [
      ['gemini-tab',tab=>isGeminiUrl(tab.url),'לא נמצאה כרטיסיית Gemini'],
      ['target-tab',tab=>{try{safeUrl(tab.url);return true;}catch{return false;}},'בחרי אתר פתוח']
    ]) {
      const select=$(field),before=Number(select.value) || (field==='gemini-tab'?state?.geminiTabId:state?.targetTabId);
      const candidates=tabs.filter(predicate);
      select.replaceChildren(new Option(placeholder,''));
      for (const tab of candidates) select.add(new Option((tab.title || tab.url).slice(0,90),String(tab.id)));
      const chosen=candidates.find(tab=>tab.id===before) || candidates.find(tab=>tab.active) || (field==='gemini-tab'?candidates[0]:null);
      if (chosen) select.value=String(chosen.id);
    }
  } finally { refreshing=false; }
}
function bind(id,fn) {
  $(id).addEventListener('click',async()=> {
    try { notice(''); await fn(); }
    catch(error){ notice(error.message); }
  });
}
bind('refresh',refreshTabs);
bind('open-gemini',async()=>{ await chrome.tabs.create({url:'https://gemini.google.com/app',active:true}); await refreshTabs(); });
bind('diagnose',async()=>{
  const result=await send('DIAGNOSTICS',{geminiTabId:Number($('gemini-tab').value),adapter});
  $('connection').textContent=result.editorFound && result.sendFound?'שדה ושליחה זוהו':'נדרש חיבור ידני';
  notice(result.draftPresent?'קיימת טיוטה בשיחת Gemini. שלחי או מחקי אותה לפני התחלה.':
    !result.editorFound || !result.sendFound?'מבנה האתר לא זוהה. ודאי שאת בשיחה רגילה, או השתמשי במצב ידני.':'');
});
bind('start',async()=> {
  const targetTabId=Number($('target-tab').value),geminiTabId=Number($('gemini-tab').value);
  const task=$('task').value.trim();
  if (!task || !targetTabId || !geminiTabId) throw new Error('בחרי שתי כרטיסיות וכתבי משימה.');
  const tab=tabs.find(tab=>tab.id===targetTabId); if (!tab) throw new Error('רענני את רשימת הכרטיסיות.');
  // Call request directly from the click gesture, before any message or async tab lookup.
  if (!await chrome.permissions.request({origins:[originPattern(tab.url)]})) throw new Error('לא אושרה הרשאת גישה לאתר.');
  $('start').disabled=true;
  try { render(await send('START',{task,targetTabId,geminiTabId,mode:$('mode').value,adapter})); }
  finally { await loadState(); }
});
bind('stop',async()=>render(await send('STOP')));
bind('approve',async()=> {
  const pending=state.pending,sessionId=state.sessionId;
  if (!pending) throw new Error('אין פעולה ממתינה.');
  if (pending.action.kind==='navigate' && !await chrome.permissions.request({origins:[originPattern(pending.action.url)]})) throw new Error('לא אושרה הרשאת גישה לאתר החדש.');
  $('approve').disabled=true;
  try { render(await send('APPROVE',{sessionId,requestId:pending.requestId})); }
  finally { $('approve').disabled=false; await loadState(); }
});
bind('reject',async()=>render(await send('REJECT',{sessionId:state.sessionId,requestId:state.pending?.requestId})));
bind('grant-site',async()=> {
  const pending=state.pending,sessionId=state.sessionId;
  if (state.status!=='site-access' || !pending) throw new Error('אין אתר שממתין להרשאת גישה.');
  if (!await chrome.permissions.request({origins:[originPattern(pending.action.url)]})) throw new Error('לא ניתנה הרשאת גישה לאתר.');
  render(await send('HOST_CONTINUE',{sessionId,requestId:pending.requestId}));
});
bind('resume',async()=> {
  const tab=await chrome.tabs.get(state.targetTabId);
  // Chrome preserves user activation during this extension API lookup.
  if (!await chrome.permissions.request({origins:[originPattern(tab.url)]})) throw new Error('לא אושרה הרשאת גישה לאתר.');
  render(await send('CONTINUE'));
});
bind('copy-prompt',async()=> {
  try { await navigator.clipboard.writeText(state.prompt); }
  catch { $('prompt').closest('details').open=true; $('prompt').focus(); $('prompt').select(); if (!document.execCommand('copy')) throw new Error('ההודעה מוצגת. סמני והעתיקי באמצעות Ctrl+C.'); }
  $('copy-prompt').textContent='הועתק — אפשר להדביק ב־Gemini';
  setTimeout(()=>{$('copy-prompt').textContent='העתקת ההודעה ל־Gemini';},2500);
});
bind('import',async()=> {
  if (!state.awaiting) throw new Error('אין בקשה שממתינה לתשובה.');
  const result=await send('IMPORT_REPLY',{text:$('reply').value,sessionId:state.sessionId,requestId:state.awaiting.requestId});
  $('reply').value=''; render(result);
});
bind('retry-gemini',async()=> {
  if (!state.awaiting) throw new Error('אין בקשה שממתינה לתשובה.');
  $('retry-gemini').disabled=true;
  try { render(await send('RETRY_GEMINI',{sessionId:state.sessionId,requestId:state.awaiting.requestId})); }
  finally { $('retry-gemini').disabled=false; await loadState(); }
});
bind('clear',async()=>{ render(await send('RESET')); $('reply').value=''; });
bind('save-settings',async()=> {
  adapter={editor:$('editor-selector').value.trim(),send:$('send-selector').value.trim(),response:$('response-selector').value.trim()};
  for (const value of Object.values(adapter)) if (value) { try{document.querySelector(value);}catch{throw new Error('סלקטור CSS לא תקין.');} }
  if (adapter.response && /^(?:body|html|\*|main)$/i.test(adapter.response)) throw new Error('בחרי מיכל תשובת מודל בלבד, לא את כל העמוד.');
  await chrome.storage.local.set({gwbAdapter:adapter}); $('connection').textContent='ההגדרות נשמרו';
});
bind('revoke',async()=> {
  render(await send('STOP'));
  const permissions=await chrome.permissions.getAll();
  const origins=(permissions.origins || []).filter(origin=>origin!=='https://gemini.google.com/*');
  if (origins.length) await chrome.permissions.remove({origins});
  $('connection').textContent='הרשאות אתרי היעד הוסרו';
});
chrome.runtime.onMessage.addListener(message=> { if (message.type==='STATE_CHANGED') loadState().catch(()=>{}); });
chrome.tabs.onCreated.addListener(()=>refreshTabs().catch(()=>{}));
chrome.tabs.onRemoved.addListener(()=>refreshTabs().catch(()=>{}));
chrome.tabs.onUpdated.addListener((_id,info)=> { if (info.status==='complete') refreshTabs().catch(()=>{}); });
async function init(){
  adapter=(await chrome.storage.local.get('gwbAdapter')).gwbAdapter || {};
  $('editor-selector').value=adapter.editor || ''; $('send-selector').value=adapter.send || ''; $('response-selector').value=adapter.response || '';
  await loadState(); await refreshTabs();
  if (state?.task) $('task').value=state.task;
  if (state?.mode) $('mode').value=state.mode;
}
init().catch(error=>notice(error.message));
