import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import {pathToFileURL} from 'node:url';

const fixtureUrl='https://fixture.example.test/page';
const geminiUrl='https://gemini.google.com/app';
const snapshot=()=>({documentKey:'doc1',snapshotKey:'snap1',url:fixtureUrl,title:'בדיקה',text:'שעות פתיחה 09:00–17:00',
  elements:[{id:'e1',tag:'input',label:'חיפוש',type:'search',context:{search:true}},
    {id:'e2',tag:'button',label:'חיפוש באתר',context:{submit:true,search:true}},
    {id:'e3',tag:'button',label:'מחיקת הכול'},
    {id:'e4',tag:'button',label:'שלח הודעה'},
    {id:'e5',tag:'select',label:'Role'},
    {id:'e6',tag:'button',label:'Continue',context:{submit:true,search:false}},
    {id:'e7',tag:'a',label:'עמוד נוסף',href:'https://second.example.test/article'}],scroll:{y:0}});
const listener=()=>({handlers:[],addListener(fn){this.handlers.push(fn);}});

async function harness() {
  const stored={}; const applied=[]; const sent=[]; const alarms=[];let targetUrl=fixtureUrl;
  const runtimeListener=listener(),onAlarm=listener(),onRemoved=listener();
  const mock={
    storage:{session:{async get(key){return {[key]:stored[key]};},async set(value){Object.assign(stored,structuredClone(value));},async setAccessLevel(){} }},
    sidePanel:{async setPanelBehavior(){}},
    runtime:{id:'test-extension',getURL:name=>`chrome-extension://test-extension/${name}`,onMessage:runtimeListener,async sendMessage(){return {}; }},
    tabs:{
      async get(id){if(id===1)return {id,url:targetUrl,status:'complete'};if(id===2)return {id,url:geminiUrl,status:'complete'};throw Error('No tab');},
      async sendMessage(_id,message){sent.push(message);return {ok:true,result:{sent:true}};},
      async update(id,properties){applied.push({kind:'navigate',id,...properties});if(id===1 && properties.url)targetUrl=properties.url;return {id,...properties};},
      onRemoved
    },
    scripting:{async executeScript(options){
      if(options.files)return [{result:null}];
      if(options.args){
        const action=options.args[0].action;
        if(action.kind==='verify')return [{result:{ok:true}}];
        if(action.kind==='click' && action.element==='e7')return [{result:{ok:true,navigate:'https://second.example.test/article'}}];
        applied.push(action);return [{result:{ok:true,message:'בוצע'}}];
      }
      return [{result:{...snapshot(),url:targetUrl}}];
    }},
    permissions:{async contains(){return true;},onRemoved:listener()},
    alarms:{async create(name,options){alarms.push({name,...options});},async clear(){return true;},onAlarm}
  };
  globalThis.chrome=mock;
  const directory=await fs.mkdtemp(path.join(os.tmpdir(),'gwb-worker-'));
  const code=await fs.readFile(new URL('../background.js',import.meta.url),'utf8');
  await fs.writeFile(path.join(directory,'worker.mjs'),code.replace("'./core.js'",JSON.stringify(new URL('../core.js',import.meta.url).href)));
  await import(pathToFileURL(path.join(directory,'worker.mjs')).href+'?test='+Math.random());
  const panel={id:'test-extension',url:'chrome-extension://test-extension/panel.html'};
  const gemini={id:'test-extension',url:geminiUrl,frameId:0,tab:{id:2,url:geminiUrl}};
  const dispatch=(message,sender=panel)=>new Promise(resolve=>{
    const handler=runtimeListener.handlers[0]; const waiting=handler(message,sender,resolve);if(!waiting)resolve({ok:false,error:'No handler'});
  });
  const state=async()=> (await dispatch({type:'GET_STATE'})).result;
  const start=()=>dispatch({type:'START',task:'חפשי מידע',targetTabId:1,geminiTabId:2,mode:'auto'});
  const reply=async(action,source=gemini)=>{
    const s=await state(),requestId=s.awaiting.requestId;
    return dispatch({type:'GEMINI_REPLY',sessionId:s.sessionId,requestId,text:JSON.stringify({protocol:'gwb/1',requestId,reason:'הסבר',action})},source);
  };
  return {mock,stored,applied,sent,alarms,dispatch,state,start,reply,panel,gemini,cleanup:()=>fs.rm(directory,{recursive:true,force:true})};
}

test('worker executes ordinary search actions automatically and holds only a serious action for one-time approval',async()=>{
  const h=await harness();
  try{
    assert.equal((await h.start()).ok,true);
    assert.equal((await h.state()).status,'waiting');assert.equal(h.sent[0].type,'GEMINI_SEND');
    assert.equal((await h.reply({kind:'type',element:'e1',text:'ספרים'})).ok,true);
    assert.equal((await h.state()).status,'waiting');assert.equal(h.applied[0].text,'ספרים');
    assert.equal((await h.reply({kind:'click',element:'e2'})).ok,true);
    assert.equal((await h.state()).status,'waiting');assert.equal(h.applied.length,2);
    await h.reply({kind:'click',element:'e3'});
    const pending=await h.state();assert.equal(pending.status,'approval');assert.equal(h.applied.length,2);
    const approval={type:'APPROVE',requestId:pending.pending.requestId,sessionId:pending.sessionId};
    assert.equal((await h.dispatch(approval)).ok,true);
    assert.equal(h.applied.length,3);assert.equal(h.applied[2].element,'e3');
    const next=await h.state();assert.equal(next.status,'waiting');assert.notEqual(next.awaiting.requestId,pending.pending.requestId);
    assert.equal((await h.dispatch(approval)).ok,false);assert.equal(h.applied.length,3);
    assert.equal((await h.reply({kind:'done',summary:'בוצע'})).ok,true);assert.equal((await h.state()).answer,'בוצע');
  }finally{await h.cleanup();}
});

test('STOP invalidates old replies and approvals without performing mutations',async()=>{
  const h=await harness();
  try{
    await h.start();await h.reply({kind:'click',element:'e3'});const before=await h.state();
    await h.dispatch({type:'STOP'});assert.equal((await h.state()).status,'stopped');
    assert.equal((await h.dispatch({type:'APPROVE',requestId:before.pending.requestId,sessionId:before.sessionId})).ok,false);
    const late=await h.dispatch({type:'GEMINI_REPLY',sessionId:before.sessionId,requestId:before.pending.requestId,text:'anything'},h.gemini);
    assert.equal(late.ok,false);assert.equal((await h.state()).status,'stopped');assert.deepEqual(h.applied,[]);
  }finally{await h.cleanup();}
});

test('commands from a target tab or iframe are rejected without changing the active request',async()=>{
  const h=await harness();
  try{
    await h.start();const initial=await h.state();
    const fake={id:'test-extension',url:fixtureUrl,frameId:0,tab:{id:1,url:fixtureUrl}};
    assert.equal((await h.reply({kind:'click',element:'e2'},fake)).ok,false);
    assert.equal((await h.reply({kind:'click',element:'e2'},{...h.gemini,frameId:1})).ok,false);
    const after=await h.state();assert.equal(after.status,'waiting');assert.equal(after.awaiting.requestId,initial.awaiting.requestId);
    assert.deepEqual(h.applied,[]);
  }finally{await h.cleanup();}
});

test('invalid model commands use manual fallback without discarding the pending nonce',async()=>{
  const h=await harness();
  try{
    await h.start();const initial=await h.state();
    assert.equal((await h.reply({kind:'eval',code:'steal()'})).ok,false);
    const rejected=await h.state();assert.equal(rejected.status,'manual');assert.equal(rejected.awaiting.requestId,initial.awaiting.requestId);assert.deepEqual(h.applied,[]);
    assert.equal((await h.reply({kind:'click',element:'e900'})).ok,false);assert.equal((await h.state()).awaiting.requestId,initial.awaiting.requestId);
    assert.equal((await h.reply({kind:'done',summary:'חיבור ידני תקין'})).ok,true);assert.equal((await h.state()).status,'done');
  }finally{await h.cleanup();}
});

test('missing host permission pauses work and never injects a target script',async()=>{
  const h=await harness();
  try{
    await h.start();h.mock.permissions.contains=async()=>false;
    const result=await h.reply({kind:'click',element:'e2'});
    assert.equal(result.ok,false);assert.equal((await h.state()).status,'permission');assert.deepEqual(h.applied,[]);
  }finally{await h.cleanup();}
});

test('publishing, permission changes and non-search submission remain blocked until approved',async()=>{
  for(const action of [{kind:'click',element:'e4'},{kind:'select',element:'e5',value:'admin'},{kind:'click',element:'e6'}]){
    const h=await harness();
    try{await h.start();await h.reply(action);const s=await h.state();assert.equal(s.status,'approval');assert.ok(s.pending.approvalReason);assert.deepEqual(h.applied,[]);}
    finally{await h.cleanup();}
  }
});

test('routine cross-site navigation proceeds automatically if Chrome already granted host access',async()=>{
  const h=await harness();
  try{
    await h.start();const r=await h.reply({kind:'navigate',url:'https://second.example.test/article'});
    assert.equal(r.ok,true);assert.equal((await h.state()).status,'waiting');
    assert.equal(h.applied.filter(action=>action.kind==='navigate').length,1);
    assert.equal((await h.state()).pending,null);
  }finally{await h.cleanup();}
});

test('a new host pauses for Chrome access, resumes the exact navigation once, and never asks for action approval',async()=>{
  const h=await harness();let granted=false;
  try{
    h.mock.permissions.contains=async({origins})=>!origins[0].includes('second.example.test') || granted;
    await h.start();await h.reply({kind:'navigate',url:'https://second.example.test/article'});
    const blocked=await h.state();assert.equal(blocked.status,'site-access');assert.deepEqual(h.applied,[]);
    granted=true;
    const resume={type:'HOST_CONTINUE',sessionId:blocked.sessionId,requestId:blocked.pending.requestId};
    assert.equal((await h.dispatch(resume)).ok,true);assert.equal((await h.state()).status,'waiting');
    assert.equal(h.applied.filter(action=>action.kind==='navigate').length,1);
    assert.equal((await h.dispatch(resume)).ok,false);assert.equal(h.applied.filter(action=>action.kind==='navigate').length,1);
  }finally{await h.cleanup();}
});

test('a cross-origin ordinary link opens without a second confirmation when host access exists',async()=>{
  const h=await harness();
  try{
    await h.start();assert.equal((await h.reply({kind:'click',element:'e7'})).ok,true);
    assert.equal((await h.state()).status,'waiting');assert.equal(h.applied[0].kind,'navigate');
  }finally{await h.cleanup();}
});

test('a mutation-looking navigation URL is held before any tab update',async()=>{
  const h=await harness();
  try{
    await h.start();await h.reply({kind:'navigate',url:'https://fixture.example.test/delete/record'});
    assert.equal((await h.state()).status,'approval');assert.deepEqual(h.applied,[]);
  }finally{await h.cleanup();}
});

test('a Gemini UI adapter failure exposes a usable manual request',async()=>{
  const h=await harness();
  try{
    h.mock.tabs.sendMessage=async()=>({ok:false,error:'Editor not found'});
    await h.start();const s=await h.state();assert.equal(s.status,'manual');assert.match(s.prompt,/gwb\/1/);assert.ok(s.awaiting);assert.deepEqual(h.applied,[]);
  }finally{await h.cleanup();}
});

test('non-JSON website replies trigger at most two corrections with fresh request IDs and no actions',async()=>{
  const h=await harness();
  try{
    await h.start();const initial=await h.state();let previous=initial;
    for(let attempt=1;attempt<=2;attempt++){
      const result=await h.dispatch({type:'GEMINI_REPLY',sessionId:previous.sessionId,requestId:previous.awaiting.requestId,text:'איני יכול לגשת לדפדפן.'},h.gemini);
      assert.equal(result.ok,true);const corrected=await h.state();
      assert.equal(corrected.status,'waiting');assert.notEqual(corrected.awaiting.requestId,previous.awaiting.requestId);
      assert.equal(corrected.awaiting.recoveryAttempts,attempt);assert.match(corrected.prompt,/FORMAT CORRECTION/);
      assert.equal(corrected.steps,0);assert.deepEqual(h.applied,[]);
      const late=await h.dispatch({type:'GEMINI_REPLY',sessionId:previous.sessionId,requestId:previous.awaiting.requestId,text:'late'},h.gemini);
      assert.equal(late.ok,false);assert.equal((await h.state()).awaiting.requestId,corrected.awaiting.requestId);
      previous=corrected;
    }
    const rejected=await h.dispatch({type:'GEMINI_REPLY',sessionId:previous.sessionId,requestId:previous.awaiting.requestId,text:'תשובה עדיין בלי JSON'},h.gemini);
    assert.equal(rejected.ok,false);const fallback=await h.state();
    assert.equal(fallback.status,'manual');assert.equal(fallback.lastReply,'תשובה עדיין בלי JSON');
    assert.equal(fallback.awaiting.requestId,previous.awaiting.requestId);
    assert.equal(h.sent.filter(m=>m.type==='GEMINI_SEND').length,3);assert.deepEqual(h.applied,[]);
    await h.reply({kind:'done',summary:'תשובה תקינה לאחר התיקון'});
    assert.equal((await h.state()).status,'done');assert.equal((await h.state()).lastReply,'');
  }finally{await h.cleanup();}
});
test('an old model nonce is never rewritten and a corrected serious action still requires approval',async()=>{
  const h=await harness();
  try{
    await h.start();const s=await h.state();
    const text=JSON.stringify({protocol:'gwb/1',requestId:'old-request',reason:'מחיקה',action:{kind:'click',element:'e3'}});
    await h.dispatch({type:'GEMINI_REPLY',sessionId:s.sessionId,requestId:s.awaiting.requestId,text},h.gemini);
    const correction=await h.state();assert.equal(correction.status,'waiting');
    assert.notEqual(correction.awaiting.requestId,s.awaiting.requestId);assert.deepEqual(h.applied,[]);
    await h.reply({kind:'click',element:'e3'});assert.equal((await h.state()).status,'approval');assert.deepEqual(h.applied,[]);
  }finally{await h.cleanup();}
});
test('manual import errors keep the current nonce and expose the captured reply without automatic retries',async()=>{
  const h=await harness();
  try{
    await h.dispatch({type:'START',task:'קראי את העמוד',targetTabId:1,geminiTabId:2,mode:'manual'});
    const s=await h.state();
    const result=await h.dispatch({type:'IMPORT_REPLY',sessionId:s.sessionId,requestId:s.awaiting.requestId,text:'אין JSON'});
    assert.equal(result.ok,false);const rejected=await h.state();
    assert.equal(rejected.status,'manual');assert.equal(rejected.awaiting.requestId,s.awaiting.requestId);
    assert.equal(rejected.lastReply,'אין JSON');assert.equal(h.sent.length,0);assert.deepEqual(h.applied,[]);
  }finally{await h.cleanup();}
});
test('failed correction delivery retains a fresh manual prompt and does not execute the rejected reply',async()=>{
  const h=await harness();
  try{
    await h.start();const s=await h.state();
    h.mock.tabs.sendMessage=async()=>({ok:false,error:'קיימת טיוטה אישית'});
    const result=await h.dispatch({type:'GEMINI_REPLY',sessionId:s.sessionId,requestId:s.awaiting.requestId,text:'not JSON'},h.gemini);
    assert.equal(result.ok,true);const fallback=await h.state();assert.equal(fallback.status,'manual');
    assert.match(fallback.lastError,/טיוטה/);assert.notEqual(fallback.awaiting.requestId,s.awaiting.requestId);
    assert.ok(fallback.prompt.includes(fallback.awaiting.requestId));assert.deepEqual(h.applied,[]);
  }finally{await h.cleanup();}
});
test('panel reconnection cancels an old watcher and reads the page again under a new nonce',async()=>{
  const h=await harness();
  try{
    await h.start();await h.reply({kind:'eval',code:'blocked'});const s=await h.state();assert.equal(s.status,'manual');
    const stale=await h.dispatch({type:'RETRY_GEMINI',sessionId:s.sessionId,requestId:'old'});
    assert.equal(stale.ok,false);assert.equal((await h.state()).awaiting.requestId,s.awaiting.requestId);
    const result=await h.dispatch({type:'RETRY_GEMINI',sessionId:s.sessionId,requestId:s.awaiting.requestId});
    assert.equal(result.ok,true);const reconnected=await h.state();assert.equal(reconnected.status,'waiting');
    assert.notEqual(reconnected.awaiting.requestId,s.awaiting.requestId);assert.equal(reconnected.awaiting.recoveryAttempts,0);
    assert.deepEqual(h.sent.slice(-2).map(m=>m.type),['GEMINI_CANCEL','GEMINI_SEND']);assert.deepEqual(h.applied,[]);
  }finally{await h.cleanup();}
});
test('STOP while a correction reads the page prevents a new Gemini prompt and all target actions',async()=>{
  const h=await harness();let release,entered;
  const gate=new Promise(resolve=>release=resolve),reading=new Promise(resolve=>entered=resolve);
  try{
    await h.start();const s=await h.state(),getTab=h.mock.tabs.get;
    h.mock.tabs.get=async id=>{if(id===1){entered();await gate;}return getTab(id);};
    const correction=h.dispatch({type:'GEMINI_REPLY',sessionId:s.sessionId,requestId:s.awaiting.requestId,text:'not JSON'},h.gemini);
    await reading;assert.equal((await h.dispatch({type:'STOP'})).ok,true);release();await correction;
    assert.equal((await h.state()).status,'stopped');assert.equal(h.sent.filter(m=>m.type==='GEMINI_SEND').length,1);
    assert.deepEqual(h.applied,[]);
  }finally{release();await h.cleanup();}
});
