import {buildPrompt,parseReply,describeAction,originPattern,safeUrl,isGeminiUrl,assessAction,completionOutcome,isBridgeCapabilityRefusal,MAX_STEPS} from './core.js';

const key = 'gwbState';
const emptyState = () => ({status:'idle',sessionId:null,task:'',targetTabId:null,geminiTabId:null,
  mode:'auto',steps:0,maxSteps:MAX_STEPS,bridgeReminders:0,completionStatus:'',logs:[],prompt:'',answer:'',lastError:'',lastResult:'',lastReply:'',
  observation:null,awaiting:null,pending:null,deadline:0,adapter:{}});
let state = emptyState(), queue = Promise.resolve();
const ready = chrome.storage.session.get(key).then(stored => { if (stored[key]) state = stored[key]; });
chrome.storage.session.setAccessLevel({accessLevel:'TRUSTED_CONTEXTS'}).catch(()=>{});
chrome.sidePanel.setPanelBehavior({openPanelOnActionClick:true}).catch(()=>{});
const delay = ms => new Promise(resolve=>setTimeout(resolve,ms));
const active = () => !['idle','done','stopped','error'].includes(state.status);
const current = id => state.sessionId === id && active();
function staleRequest(message) {
  const error=new Error(message); error.preserveState=true; return error;
}

function log(kind,message) {
  state.logs.push({at:Date.now(),kind,message:String(message).slice(0,1400)});
  state.logs = state.logs.slice(-60);
}
function view() {
  const {observation,...rest} = state;
  return {...rest,observation:observation?{url:observation.url,title:observation.title,elementCount:observation.elements.length}:null};
}
async function save() {
  await chrome.storage.session.set({[key]:state});
  chrome.runtime.sendMessage({type:'STATE_CHANGED'}).catch(()=>{});
}
function trustedPanel(sender) {
  return sender.id === chrome.runtime.id && sender.url === chrome.runtime.getURL('panel.html');
}
function trustedGemini(sender) {
  return sender.id === chrome.runtime.id && sender.frameId === 0 && sender.tab?.id === state.geminiTabId &&
    isGeminiUrl(sender.url) && isGeminiUrl(sender.tab.url);
}
async function targetTab() {
  const tab = await chrome.tabs.get(state.targetTabId);
  safeUrl(tab.url);
  const allowed = await chrome.permissions.contains({origins:[originPattern(tab.url)]});
  if (!allowed) {
    const error = new Error('נדרשת הרשאה לאתר החדש. אשרי גישה בפאנל והמשיכי.');
    error.code = 'HOST_PERMISSION'; throw error;
  }
  return tab;
}
async function snapshot(id) {
  const tab = await targetTab();
  if (!current(id)) return null;
  await chrome.scripting.executeScript({target:{tabId:tab.id,frameIds:[0]},files:['target.js']});
  if (!current(id)) return null;
  const results = await chrome.scripting.executeScript({target:{tabId:tab.id,frameIds:[0]},func:()=>globalThis.__gwbTarget.snapshot()});
  if (!results[0]?.result) throw new Error('לא ניתן לקרוא את תוכן הכרטיסייה.');
  const result = results[0].result;
  safeUrl(result.url);
  const after = await chrome.tabs.get(tab.id);
  if (after.url !== result.url) throw new Error('הכרטיסייה השתנתה בזמן הקריאה. לחצי על המשך כדי לנסות שוב.');
  return result;
}
async function geminiMessage(message) {
  const validRequest=()=>message.type!=='GEMINI_SEND' || (current(message.sessionId) && state.awaiting?.requestId===message.requestId);
  const tab = await chrome.tabs.get(state.geminiTabId);
  if (!validRequest()) throw staleRequest('הבקשה נעצרה לפני השליחה.');
  if (!isGeminiUrl(tab.url)) throw new Error('כרטיסיית Gemini נסגרה או עברה לאתר אחר.');
  let response;
  try { response = await chrome.tabs.sendMessage(tab.id,message,{frameId:0}); }
  catch {
    if (!validRequest()) throw staleRequest('הבקשה נעצרה לפני השליחה.');
    await chrome.scripting.executeScript({target:{tabId:tab.id,frameIds:[0]},files:['reply-parser.js','gemini.js']});
    if (!validRequest()) throw staleRequest('הבקשה נעצרה לפני השליחה.');
    response = await chrome.tabs.sendMessage(tab.id,message,{frameId:0});
  }
  if (!response?.ok) throw new Error(response?.error || 'לא התקבלה תשובה מגשר Gemini.');
  return response.result;
}
async function next(id,{recoveryAttempts=0,formatError='',bridgeReminder=false}={}) {
  if (!current(id)) return;
  if (state.steps >= state.maxSteps) {
    state.status='paused'; state.lastError='הגעת למגבלת 20 הפעולות למשימה. אפשר להתחיל משימה חדשה.';
    state.awaiting=null; state.pending=null; await save(); return;
  }
  state.status='reading'; state.lastError=''; state.pending=null; state.awaiting=null; state.prompt=''; state.answer=''; state.completionStatus='';
  if (!recoveryAttempts && !bridgeReminder) state.lastReply='';
  await save();
  const observation = await snapshot(id);
  if (!observation || !current(id)) return;
  const requestId=crypto.randomUUID();
  state.observation=observation; state.awaiting={requestId,sessionId:id,recoveryAttempts};
  state.prompt=buildPrompt({task:state.task,requestId,observation,steps:state.steps,lastResult:state.lastResult,formatError,
    bridgeReminder:bridgeReminder || !!state.bridgeReminders});
  state.status=state.mode === 'manual' ? 'manual' : 'waiting';
  state.deadline=Date.now()+240000;
  await chrome.alarms.create('gwb-timeout',{when:state.deadline});
  log('read',`נקרא העמוד: ${observation.title || new URL(observation.url).hostname} (${observation.elements.length} רכיבים).`);
  await save();
  if (state.mode==='auto' && current(id)) {
    try {
      await geminiMessage({type:'GEMINI_SEND',requestId,sessionId:id,prompt:state.prompt,adapter:state.adapter});
      if (current(id)) { log('send','הבקשה נשלחה דרך אתר Gemini.'); await save(); }
    } catch (error) {
      if (current(id)) {
        state.status='manual'; state.lastError=error.message;
        log('notice','השליחה האוטומטית לא הושלמה. אפשר להעתיק את ההודעה ולייבא תשובה ידנית.'); await save();
      }
    }
  }
}
async function hostAccess(reply,url) {
  state.pending={...reply,action:{kind:'navigate',url},description:`פתיחת כתובת: ${url}`};
  state.status='site-access'; state.lastError='';
  log('permission',`Chrome דורש הרשאת גישה לאתר: ${new URL(url).hostname}`);
  await save();
}
async function execute(id,reply) {
  if (!current(id)) return;
  state.status='acting'; state.pending=null; await save();
  const action=reply.action, observation=state.observation;
  const tab=await targetTab();
  if (!current(id)) return;
  if (tab.url !== observation.url) throw new Error('כתובת הכרטיסייה השתנתה מאז האישור. לא בוצעה פעולה.');
  let result;
  if (action.kind === 'navigate') {
    await chrome.scripting.executeScript({target:{tabId:tab.id,frameIds:[0]},
      func:payload=>globalThis.__gwbTarget.execute(payload),
      args:[{action:{kind:'verify'},expectedDocumentKey:observation.documentKey,expectedSnapshotKey:observation.snapshotKey,expectedUrl:observation.url}]});
    if (!await chrome.permissions.contains({origins:[originPattern(action.url)]})) {
      if (current(id)) await hostAccess(reply,action.url);
      return;
    }
    if (!current(id)) return;
    await chrome.tabs.update(tab.id,{url:safeUrl(action.url)});
    result={ok:true,message:'נשלחה בקשת ניווט לכתובת.'};
  } else if (action.kind==='wait') {
    await delay(action.ms); result={ok:true,message:'ההמתנה הסתיימה.'};
  } else {
    const results = await chrome.scripting.executeScript({target:{tabId:tab.id,frameIds:[0]},
      func:payload=>globalThis.__gwbTarget.execute(payload),
      args:[{action,expectedDocumentKey:observation.documentKey,expectedSnapshotKey:observation.snapshotKey,expectedUrl:observation.url}]});
    result=results[0]?.result;
    if (result?.navigate) {
      safeUrl(result.navigate);
      if (!await chrome.permissions.contains({origins:[originPattern(result.navigate)]})) {
        if (current(id)) await hostAccess(reply,result.navigate);
        return;
      }
      if (!current(id)) return;
      await chrome.tabs.update(tab.id,{url:result.navigate});
    }
  }
  if (!current(id)) return;
  state.steps++; state.lastResult={...(result || {ok:true}),action};
  log('action',describeAction(action,observation)); await save();
  await delay(action.kind==='navigate' || result?.navigate ? 1100 : 450);
  if (!current(id)) return;
  // Poll the actual tab load state instead of pretending that a fixed delay guarantees readiness.
  for (let attempt=0;attempt<24;attempt++) {
    const latest = await chrome.tabs.get(state.targetTabId);
    if (latest.status === 'complete') break;
    await delay(350); if (!current(id)) return;
  }
  await next(id);
}
async function finishReply(id,action,{automatic=false}={}) {
  const outcome=completionOutcome(action);
  state.awaiting=null; state.pending=null; state.deadline=0;
  await chrome.alarms.clear('gwb-timeout');
  if (!current(id)) return view();
  if (automatic && outcome.capabilityMismatch && (state.bridgeReminders || 0)<1) {
    state.bridgeReminders=(state.bridgeReminders || 0)+1;
    log('notice','Gemini לא זיהה את יכולת התוסף. נשלחת הבהרת חיבור אחת, בלי לבצע פעולה מהתשובה הזו.');
    await next(id,{bridgeReminder:true});
    return view();
  }
  state.completionStatus=outcome.status; state.answer=action.summary; state.prompt='';
  if (outcome.status==='completed') {
    state.status='done'; state.observation=null; state.lastReply=''; state.lastError='';
    log('done','Gemini דיווח שהמשימה הושלמה.');
  } else {
    state.status='paused';
    state.lastError=outcome.status==='needs_user'?'נדרש צעד ידני שהחיבור אינו יכול לבצע. הפרטים מופיעים למטה.':
      outcome.capabilityMismatch?'Gemini עדיין לא החזיר פעולה דרך התוסף. המשימה לא הושלמה.':'Gemini עצר לפני השלמת המשימה. הסיבה מופיעה למטה.';
    log('blocked',state.lastError);
  }
  await save(); return view();
}
async function receiveReply(message) {
  if (!state.awaiting || !['waiting','manual'].includes(state.status) ||
      message.sessionId !== state.sessionId || message.requestId !== state.awaiting.requestId) {
    throw staleRequest('זו תשובה לבקשה ישנה או למשימה שנעצרה. היא לא בוצעה.');
  }
  const id=state.sessionId;
  state.lastReply=typeof message.text==='string'?message.text.slice(0,40000):'';
  let reply;
  try { reply=parseReply(message.text,state.awaiting.requestId); }
  catch (error) {
    // A plain capability denial needs an explanation of the bridge, not a repeated format-only demand.
    if (error.code==='REPLY_MISSING' && isBridgeCapabilityRefusal(message.text)) {
      return finishReply(id,{kind:'done',status:'blocked',summary:message.text.slice(0,5000)},
        {automatic:message.type==='GEMINI_REPLY' && state.status==='waiting' && state.mode==='auto'});
    }
    const attempts=state.awaiting.recoveryAttempts || 0;
    if (message.type==='GEMINI_REPLY' && state.status==='waiting' && state.mode==='auto' &&
        error.replyRecoverable && attempts<2) {
      log('notice',`${error.message} מבקש מ־Gemini תשובה מתוקנת (${attempts+1}/2).`);
      // Never rewrite a nonce or reuse old element IDs. Read the page again and create a new request.
      await next(id,{recoveryAttempts:attempts+1,formatError:error.message});
      return view();
    }
    throw error;
  }
  if (reply.action.element && !state.observation.elements.some(el=>el.id===reply.action.element)) throw new Error('הרכיב אינו נמצא בעמוד שנקרא.');
  if (reply.action.kind==='done') {
    return finishReply(id,reply.action,{automatic:message.type==='GEMINI_REPLY' && state.status==='waiting' && state.mode==='auto'});
  }
  state.lastReply=''; state.lastError=''; state.awaiting=null; state.deadline=0; await chrome.alarms.clear('gwb-timeout');
  if (!current(id)) return view();
  const assessment=assessAction(reply.action,state.observation);
  if (assessment.requiresApproval) {
    const element=state.observation.elements.find(el=>el.id===reply.action.element);
    state.pending={...reply,description:describeAction(reply.action,state.observation),approvalReason:assessment.reason,navigationUrl:element?.href || ''}; state.status='approval';
    log('approval',state.pending.description); await save();
  } else {
    log('auto',`אוטומטי: ${describeAction(reply.action,state.observation)}`);
    await execute(id,reply);
  }
  return view();
}
async function stop() {
  const oldTab=state.geminiTabId;
  state.status='stopped'; state.sessionId=null; state.awaiting=null; state.pending=null;
  state.observation=null; state.prompt=''; state.lastReply=''; state.deadline=0;
  log('stop','המשימה נעצרה. תשובות מאוחרות לא יבוצעו.'); await save();
  await chrome.alarms.clear('gwb-timeout');
  if (oldTab) chrome.tabs.sendMessage(oldTab,{type:'GEMINI_CANCEL'},{frameId:0}).catch(()=>{});
  return view();
}
async function failure(error,id) {
  if (id && !current(id)) return;
  state.lastError=error.message || String(error);
  state.status=error.code==='HOST_PERMISSION' ? 'permission' : 'paused';
  state.awaiting=null; state.pending=null; state.deadline=0;
  log('error',state.lastError); await chrome.alarms.clear('gwb-timeout'); await save();
  if (state.geminiTabId) chrome.tabs.sendMessage(state.geminiTabId,{type:'GEMINI_CANCEL'},{frameId:0}).catch(()=>{});
}
async function panelCommand(message) {
  if (message.type==='GET_STATE') return view();
  if (message.type==='DIAGNOSTICS') {
    const tab=await chrome.tabs.get(message.geminiTabId);
    if (!isGeminiUrl(tab.url)) throw new Error('בחרי כרטיסייה עם אתר Gemini.');
    const saved=state.geminiTabId; state.geminiTabId=tab.id;
    try { return await geminiMessage({type:'GEMINI_DIAGNOSTICS',adapter:message.adapter || {}}); }
    finally { state.geminiTabId=saved; }
  }
  if (message.type==='START') {
    if (active()) throw staleRequest('עצרי את המשימה הנוכחית לפני תחילת משימה חדשה.');
    if (typeof message.task!=='string' || !message.task.trim() || message.task.length>4000) throw new Error('כתבי משימה באורך של עד 4,000 תווים.');
    const target=await chrome.tabs.get(message.targetTabId); safeUrl(target.url);
    if (!await chrome.permissions.contains({origins:[originPattern(target.url)]})) throw new Error('אשרי קודם גישה לכרטיסיית היעד.');
    const gemini=await chrome.tabs.get(message.geminiTabId);
    if (!isGeminiUrl(gemini.url) || gemini.id===target.id) throw new Error('בחרי כרטיסיית Gemini וכרטיסיית יעד נפרדות.');
    const adapter={};
    for (const name of ['editor','send','response']) {
      const value=message.adapter?.[name];
      if (value && (typeof value!=='string' || value.length>500)) throw new Error('סלקטור לא תקין.');
      if (value) adapter[name]=value;
    }
    state={...emptyState(),status:'reading',sessionId:crypto.randomUUID(),task:message.task.trim(),
      targetTabId:target.id,geminiTabId:gemini.id,mode:message.mode==='manual'?'manual':'auto',adapter};
    log('start','התחילה משימה בכרטיסייה שנבחרה.'); await save();
    await next(state.sessionId); return view();
  }
  if (message.type==='IMPORT_REPLY') {
    return receiveReply(message);
  }
  if (message.type==='RETRY_GEMINI') {
    if (state.status!=='manual' || state.mode!=='auto' || !state.awaiting ||
        message.sessionId!==state.sessionId || message.requestId!==state.awaiting.requestId) {
      throw staleRequest('אין בקשה מתאימה לחיבור מחדש.');
    }
    const id=state.sessionId;
    await geminiMessage({type:'GEMINI_CANCEL'});
    if (current(id)) await next(id);
    return view();
  }
  if (message.type==='APPROVE') {
    if (state.status!=='approval' || !state.pending || message.requestId !== state.pending.requestId || message.sessionId!==state.sessionId) throw staleRequest('האישור אינו שייך לפעולה הממתינה.');
    const pending=state.pending;
    await execute(state.sessionId,pending); return view();
  }
  if (message.type==='HOST_CONTINUE') {
    if (state.status!=='site-access' || !state.pending || message.requestId!==state.pending.requestId || message.sessionId!==state.sessionId) throw staleRequest('הרשאת האתר אינה שייכת לפעולה הממתינה.');
    await execute(state.sessionId,state.pending); return view();
  }
  if (message.type==='REJECT') {
    if (state.status!=='approval' || message.sessionId!==state.sessionId || message.requestId!==state.pending?.requestId) throw staleRequest('אין פעולה מתאימה לדחייה.');
    log('reject','הפעולה נדחתה. המשימה הושהתה.'); state.pending=null; state.status='paused'; state.lastError='הפעולה נדחתה. אפשר לעצור או לבקש הוראה חדשה.'; await save(); return view();
  }
  if (message.type==='CONTINUE') {
    if (!['paused','permission'].includes(state.status) || !state.sessionId) throw staleRequest('אין משימה מושהית להמשך.');
    if (state.steps>=state.maxSteps) throw new Error('מגבלת הפעולות הושגה. התחילי משימה חדשה.');
    await next(state.sessionId); return view();
  }
  if (message.type==='RESET') {
    await stop(); state=emptyState(); await save(); return view();
  }
  throw new Error('בקשה לא מוכרת.');
}

chrome.runtime.onMessage.addListener((message,sender,respond) => {
  if (message.type==='STATE_CHANGED') return;
  const panel=trustedPanel(sender);
  const process = async () => {
    await ready;
    if (panel) return panelCommand(message);
    if (!trustedGemini(sender)) throw new Error('מקור ההודעה אינו מאושר.');
    if (message.type==='GEMINI_READY') {
      if (state.status==='waiting' && state.awaiting) {
        chrome.tabs.sendMessage(state.geminiTabId,{type:'GEMINI_WATCH',...state.awaiting,adapter:state.adapter},{frameId:0}).catch(()=>{});
      }
      return {ready:true};
    }
    if (message.type==='GEMINI_REPLY') return receiveReply(message);
    throw new Error('בקשה לא מוכרת.');
  };
  if (panel && message.type==='STOP') {
    // STOP is deliberately outside the queue: invalidate the session while a slow operation awaits.
    ready.then(stop).then(result=>respond({ok:true,result}),error=>respond({ok:false,error:error.message}));
    return true;
  }
  if (panel && message.type==='GET_STATE') {
    ready.then(()=>respond({ok:true,result:view()})); return true;
  }
  const sessionBefore=state.sessionId;
  const work=queue.then(process);
  queue=work.catch(()=>{});
  work.then(result=>respond({ok:true,result}),async error=> {
    // A malformed reply cannot execute an action; keep the request available for manual correction.
    if (error.preserveState) {
      // Replayed/stale UI messages cannot interrupt a newer request.
    } else if ((panel || trustedGemini(sender)) && ['GEMINI_REPLY','IMPORT_REPLY'].includes(message.type) && ['waiting','manual'].includes(state.status)) {
      state.status='manual'; state.lastError=error.message; log('error',error.message); await save();
    } else if (['START','APPROVE','HOST_CONTINUE','CONTINUE','RETRY_GEMINI','GEMINI_REPLY','IMPORT_REPLY'].includes(message.type) &&
        active() && (panel || trustedGemini(sender))) await failure(error,state.sessionId || sessionBefore);
    respond({ok:false,error:error.message});
  });
  return true;
});
chrome.alarms.onAlarm.addListener(alarm=> {
  if (alarm.name!=='gwb-timeout') return;
  queue=queue.then(async()=> {
    await ready;
    if (state.status==='waiting' && state.deadline && Date.now()>=state.deadline) {
      state.status='manual'; state.lastError='לא התקבלה הוראה תקינה בתוך 4 דקות. בדקי את Gemini או הדביקי תשובה ידנית.';
      log('notice',state.lastError); await save();
    }
  }).catch(()=>{});
});
chrome.tabs.onRemoved.addListener(tabId=> {
  ready.then(async()=> {
    if (active() && [state.targetTabId,state.geminiTabId].includes(tabId)) await stop();
  }).catch(()=>{});
});
chrome.permissions.onRemoved.addListener(()=> {
  ready.then(async()=> {
    if (active() && state.targetTabId) {
      try { await targetTab(); } catch(error) { await failure(error,state.sessionId); }
    }
  }).catch(()=>{});
});
