(() => {
  if (globalThis.__gwbGemini) return;
  globalThis.__gwbGemini = true;
  let pending = null, timer = null, lastText = '', lastChange = 0, reporting = false, writing = null, epoch = 0;
  const visible = el => !!el && el.getClientRects().length > 0 && getComputedStyle(el).visibility !== 'hidden';
  const defaults = {
    editor: 'rich-textarea .ql-editor[contenteditable="true"],.ql-editor[contenteditable="true"],rich-textarea [contenteditable="true"],[role="textbox"][contenteditable="true"],textarea',
    send: 'button.send-button,button[data-test-id="send-button"],button[aria-label="Send message"],button[aria-label="שליחת הודעה"],button[aria-label="שליחה"]',
    response: 'model-response,[data-test-id="model-response"],.model-response-text',
    stop: 'button.stop-button,button[data-test-id="stop-button"],button[data-test-id="stop-response-button"],button[aria-label="Stop"],button[aria-label="Stop response"],button[aria-label="Stop generating"],button[aria-label="עצירה"],button[aria-label="עצירת התשובה"],button[aria-label="הפסקת התשובה"]'
  };
  const pause = ms => new Promise(resolve => setTimeout(resolve,ms));
  function all(selector) {
    try { return Array.from(document.querySelectorAll(selector)); }
    catch { throw new Error('אחד הסלקטורים בהגדרות אינו תקין.'); }
  }
  function find(selector) { return all(selector).find(visible); }
  function editorText(editor) { return editor instanceof HTMLTextAreaElement ? editor.value : editor.innerText; }
  function generating() {
    const stop = find(defaults.stop);
    return !!stop || Array.from(document.querySelectorAll('button[aria-label]')).some(el => visible(el) &&
      /^(stop(?: (?:response|generating))?|עצירה|עצירת (?:התשובה|התגובה)|הפסקת (?:התשובה|התגובה))$/i.test(el.getAttribute('aria-label') || ''));
  }
  function responseNodes(adapter) {
    const nodes = all(adapter.response || defaults.response).filter(visible);
    // A custom selector may match nested wrappers. Use only the outermost one once.
    return nodes.filter(node => !nodes.some(other=>other !== node && other.contains(node)));
  }
  function responseText(node) {
    if (!node) return '';
    const blocks=Array.from(node.querySelectorAll('message-content,.response-content,.markdown,.model-response-text,pre')).filter(visible);
    const roots=blocks.filter(block=>!blocks.some(other=>other!==block && other.contains(block)));
    // Include all answer fragments and code blocks once. The first markdown node may contain only prose.
    return (roots.length?roots.map(block=>block.innerText.trim()).filter(Boolean).join('\n\n'):node.innerText.trim());
  }
  function diagnostics(adapter = {}) {
    const editor = find(adapter.editor || defaults.editor);
    const send = find(adapter.send || defaults.send);
    return {editorFound:!!editor,sendFound:!!send,responseCount:responseNodes(adapter).length,
      generating:generating(),draftPresent:!!editorText(editor || document.createElement('textarea')).trim()};
  }
  function cancel() {
    epoch++;
    pending = null; reporting = false; lastText = ''; lastChange = 0;
    if (timer) clearInterval(timer); timer = null;
  }
  async function poll() {
    if (!pending || reporting) return;
    const job = pending;
    let nodes;
    try { nodes = responseNodes(job.adapter || {}); } catch { return; }
    const node = nodes.at(-1), text = responseText(node);
    if (!text) return;
    if (job.restored && !text.includes(job.requestId)) return;
    if (!job.restored && nodes.length <= job.beforeCount && node === job.beforeNode && text === job.beforeText) return;
    if (text !== lastText) { lastText = text; lastChange = Date.now(); return; }
    if (generating()) return;
    const stableFor=Date.now()-lastChange;
    let envelope=false, incomplete=false;
    try { globalThis.__gwbReplyParser.readEnvelope(text,job.requestId); envelope=true; }
    catch { try { incomplete=globalThis.__gwbReplyParser.inspect(text).incomplete; } catch {} }
    // A streamed fragment can pause before its code block arrives. Give it time to finish before correction.
    if (stableFor<(envelope?1800:incomplete?15000:7000)) return;
    // Only the model-response subtree can produce a command; user prompts and page text cannot.
    reporting = true;
    // Release the old request BEFORE the worker asks Gemini for the next step.
    pending = null;
    if (timer) clearInterval(timer); timer = null;
    try {
      await chrome.runtime.sendMessage({type:'GEMINI_REPLY',sessionId:job.sessionId,requestId:job.requestId,text});
    } catch { /* The panel retains a manual-import fallback; do not replay uncertain commands. */ }
    finally { if (!pending) reporting = false; }
  }
  function watch(job) {
    cancel(); pending = job; timer = setInterval(poll,650); poll();
  }
  async function writeAndSend(message) {
    if (pending || writing) throw new Error('Gemini כבר ממתין לתשובה עבור בקשה קודמת.');
    const adapter = message.adapter || {};
    if (generating()) throw new Error('Gemini עדיין כותב תשובה. המתיני לסיום או עברי למצב ידני.');
    const editor = find(adapter.editor || defaults.editor);
    if (!editor) throw new Error('לא נמצא שדה ההודעה. פתחי שיחה רגילה, התחברי לחשבון או השתמשי במצב העתקה ידנית.');
    if (editorText(editor).trim()) throw new Error('יש טיוטה קיימת בשדה Gemini. היא לא הוחלפה; שלחי או מחקי אותה ידנית.');
    const nodes = responseNodes(adapter);
    const job = {...message,adapter,beforeCount:nodes.length,beforeNode:nodes.at(-1),beforeText:responseText(nodes.at(-1))};
    const write={epoch}; writing=write;
    try {
      editor.focus();
      if (editor instanceof HTMLTextAreaElement) {
        Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype,'value').set.call(editor,message.prompt);
      } else {
        const range = document.createRange(); range.selectNodeContents(editor);
        const selection = getSelection(); selection.removeAllRanges(); selection.addRange(range);
        // The editing API preserves Quill/contenteditable handlers. It executes no model-provided code.
        if (!document.execCommand('insertText',false,message.prompt)) editor.textContent = message.prompt;
      }
      editor.dispatchEvent(new InputEvent('input',{bubbles:true,inputType:'insertText',data:message.prompt}));
      let send;
      for (let i=0;i<12;i++) {
        if (epoch!==write.epoch) throw new Error('הבקשה נעצרה לפני השליחה.');
        send = find(adapter.send || defaults.send);
        if (send && !send.disabled && send.getAttribute('aria-disabled') !== 'true') break;
        await pause(100);
      }
      if (!send || send.disabled || send.getAttribute('aria-disabled') === 'true') {
        throw new Error('כפתור השליחה לא זוהה או אינו פעיל. ההודעה מוכנה בשדה; אפשר לשלוח אותה ולהדביק את התשובה בפאנל.');
      }
      if (epoch!==write.epoch) throw new Error('הבקשה נעצרה לפני השליחה.');
      writing=null;
      watch(job); send.click();
      return {sent:true};
    } finally { if (writing===write) writing=null; }
  }
  chrome.runtime.onMessage.addListener((message,sender,respond) => {
    if (sender.id !== chrome.runtime.id) return;
    const handler = async () => {
      if (message.type === 'GEMINI_DIAGNOSTICS') return diagnostics(message.adapter);
      if (message.type === 'GEMINI_SEND') return writeAndSend(message);
      if (message.type === 'GEMINI_CANCEL') { cancel(); return {stopped:true}; }
      if (message.type === 'GEMINI_WATCH') {
        watch({...message,restored:true}); return {watching:true};
      }
      throw new Error('הודעה לא מוכרת.');
    };
    handler().then(result=>respond({ok:true,result}),error=>respond({ok:false,error:error.message}));
    return true;
  });
  chrome.runtime.sendMessage({type:'GEMINI_READY'}).catch(()=>{});
})();
