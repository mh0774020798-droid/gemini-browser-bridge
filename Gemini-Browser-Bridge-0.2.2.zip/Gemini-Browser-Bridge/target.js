(() => {
  if (globalThis.__gwbTarget?.version === '0.2.0') return;
  const documentKey = crypto.randomUUID();
  let snapshotKey = '', snapshotUrl = '', elements = new Map();
  const normalize = value => String(value || '').replace(/\s+/g, ' ').trim();
  const sensitiveRe = /pass(?:word|code)?|secret|token|api[\s_-]?key|credit|card[\s_-]?(?:number|holder)|cvv|cvc|otp|verification|security[\s_-]?code|סיסמ|קוד\s*(?:אימות|אבטחה)|אשראי|מספר\s*כרטיס/i;
  const sensitiveUrl = /[?&#](?:access_token|refresh_token|id_token|token|api[_-]?key|password|secret|authorization|auth|code)=/i;
  function visible(el) {
    if (!(el instanceof Element) || !el.isConnected || el.closest('[hidden],[inert],[aria-hidden="true"]')) return false;
    const css = getComputedStyle(el);
    return css.display !== 'none' && css.visibility !== 'hidden' && el.getClientRects().length > 0;
  }
  function label(el) {
    const ids = (el.getAttribute('aria-labelledby') || '').split(/\s+/).filter(Boolean);
    const named = ids.map(id => document.getElementById(id)?.innerText || '').join(' ');
    return normalize(el.getAttribute('aria-label') || named ||
      Array.from(el.labels || []).map(l => l.innerText).join(' ') || el.getAttribute('placeholder') ||
      (el.matches('input,textarea,[contenteditable="true"],[role="textbox"]') ? el.matches('input') && ['button','submit','reset'].includes(el.type) ? el.getAttribute('value') : '' : el.innerText) ||
      el.getAttribute('title') || el.getAttribute('name') || el.tagName.toLowerCase()).slice(0,220);
  }
  function sensitive(el) {
    const meta = [el.type, el.id, el.name, el.getAttribute('autocomplete'), el.getAttribute('aria-label'),
      el.getAttribute('placeholder'), Array.from(el.labels || []).map(l=>l.innerText).join(' ')].join(' ');
    return ['password','file','hidden'].includes(el.type) || sensitiveRe.test(meta) ||
      ['current-password','new-password','one-time-code'].includes(el.getAttribute('autocomplete')) ||
      (el.getAttribute('autocomplete') || '').startsWith('cc-');
  }
  function href(el) {
    const anchor = el.closest('a[href]');
    if (!anchor) return '';
    try {
      const url = new URL(anchor.href);
      if (!['https:','http:'].includes(url.protocol) || url.username || url.password || sensitiveUrl.test(url.href)) return '[unavailable]';
      if (['gemini.google.com','accounts.google.com','chromewebstore.google.com'].includes(url.hostname)) return '[unavailable]';
      return url.href.slice(0,2048);
    } catch { return '[unavailable]'; }
  }
  function actionContext(el) {
    const form=el.form || el.closest('form');
    const description=(el.getAttribute('aria-describedby') || '').split(/\s+/).filter(Boolean)
      .map(id=>document.getElementById(id)).filter(node=>node && visible(node) && !node.matches('input,textarea,[contenteditable="true"]'))
      .map(node=>normalize(node.innerText).slice(0,180)).join(' ').slice(0,360);
    const identity=normalize([el.id,el.name].join(' ')).slice(0,220);
    const intent=normalize([el.getAttribute('data-action'),el.getAttribute('data-method'),el.getAttribute('title')].join(' ')).slice(0,250);
    const formIdentity=form?normalize([form.id,form.getAttribute('role'),form.getAttribute('name'),form.getAttribute('aria-label'),form.getAttribute('class')].join(' ')).slice(0,250):'';
    const formAction=el.getAttribute('formaction') || form?.getAttribute('action') || '';
    let resolvedAction='';
    try { const url=new URL(formAction || location.href,location.href); if (!sensitiveUrl.test(url.href) && !url.username && !url.password) resolvedAction=url.href; } catch {}
    const explicitSearch=!!el.closest('[role="search"]') || /(?:\bsearch\b|חיפוש)/i.test(formIdentity);
    const searchInput=form?.querySelector?.('input[type="search"]');
    const search=explicitSearch || !!(searchInput && visible(searchInput)) ||
      (!!form && /(?:\b(?:search|find|filter|lookup)\b|חפש|חיפוש|סנן|סינון)/i.test(label(el))) ||
      /(?:^|\/)(?:search|find|lookup)(?:\/|\?|$)/i.test(formAction);
    return {identity,intent,description,submit:!!form && ['BUTTON','INPUT'].includes(el.tagName) && el.type==='submit',
      reset:el.type==='reset',search,formAction:form?resolvedAction:'',formMethod:form?.getAttribute('method') || '',formPurpose:formIdentity};
  }
  function fingerprint(el) {
    return JSON.stringify([el.tagName, el.getAttribute('role'), el.type || '', el.name || '', label(el),
      href(el), el.form?.getAttribute('action') || '', el.getAttribute('formaction') || '',
      el.getAttribute('target') || '', el.disabled === true, el.readOnly === true, el.getAttribute('aria-disabled'),actionContext(el)]);
  }
  function pageText() {
    const walker = document.createTreeWalker(document.body || document.documentElement, NodeFilter.SHOW_TEXT);
    const texts = []; let length = 0, scanned = 0;
    while (scanned++ < 12000 && length < 12000 && walker.nextNode()) {
      const node = walker.currentNode, el = node.parentElement;
      if (!el || el.closest('script,style,noscript,textarea,input,[contenteditable="true"],[role="textbox"],select') || !visible(el)) continue;
      // Do not include text in custom sensitive controls.
      const custom = el.closest('[name],[autocomplete],[role="textbox"]');
      if (custom && sensitive(custom)) continue;
      const text = normalize(node.textContent);
      if (text) { texts.push(text); length += text.length + 1; }
    }
    return texts.join('\n').slice(0,12000);
  }
  function snapshot() {
    snapshotKey = crypto.randomUUID(); snapshotUrl = location.href; elements = new Map();
    const items = [];
    const selector = 'a[href],button,input:not([type="hidden"]),textarea,select,[role="button"],[role="link"],[role="checkbox"],[role="combobox"],[contenteditable="true"]';
    for (const el of document.querySelectorAll(selector)) {
      if (items.length >= 120) break;
      if (!visible(el) || sensitive(el) || el.disabled || el.getAttribute('aria-disabled') === 'true') continue;
      const link = href(el); if (link === '[unavailable]') continue;
      const id = `e${items.length+1}`;
      const record = {id,tag:el.tagName.toLowerCase(),role:el.getAttribute('role') || '',label:label(el),context:actionContext(el)};
      if (el.type) record.type = el.type;
      if (link) record.href = link;
      if (el.matches('select')) record.options = Array.from(el.options).slice(0,60).map(o=>({value:o.value.slice(0,500),label:normalize(o.label).slice(0,120),disabled:o.disabled}));
      if (el.matches('input[type="checkbox"],input[type="radio"]')) record.checked = el.checked;
      elements.set(id,{el,fingerprint:fingerprint(el)}); items.push(record);
    }
    return {documentKey,snapshotKey,url:snapshotUrl,title:document.title.slice(0,250),text:pageText(),
      elements:items,scroll:{y:Math.round(window.scrollY),height:document.documentElement.scrollHeight,viewport:window.innerHeight},
      note:'Only visible DOM text and at most 120 available controls. Field values, password/payment/authentication fields, frames and closed shadow roots are excluded.'};
  }
  function currentElement(action) {
    const saved = elements.get(action.element);
    if (!saved || !visible(saved.el) || sensitive(saved.el) || saved.el.disabled || saved.el.getAttribute('aria-disabled') === 'true' || fingerprint(saved.el) !== saved.fingerprint) {
      throw new Error('הרכיב השתנה מאז קריאת העמוד. לא בוצעה פעולה; יש לקרוא את העמוד מחדש.');
    }
    return saved.el;
  }
  function dispatchValue(el, value) {
    const proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype :
      el instanceof HTMLSelectElement ? HTMLSelectElement.prototype : HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(proto,'value')?.set;
    if (!setter) throw new Error('לא ניתן למלא את סוג השדה הזה.');
    setter.call(el,value);
    el.dispatchEvent(new InputEvent('input',{bubbles:true,inputType:'insertText',data:value}));
    el.dispatchEvent(new Event('change',{bubbles:true}));
  }
  function execute({action,expectedDocumentKey,expectedSnapshotKey,expectedUrl}) {
    if (documentKey !== expectedDocumentKey || snapshotKey !== expectedSnapshotKey || location.href !== expectedUrl || snapshotUrl !== expectedUrl) {
      throw new Error('העמוד השתנה מאז ההוראה. לא בוצעה פעולה.');
    }
    if (action.kind === 'verify') return {ok:true};
    if (action.kind === 'scroll') {
      window.scrollBy({top:action.pixels * (action.direction==='down'?1:-1),behavior:'instant'});
      return {ok:true,message:'העמוד נגלל.'};
    }
    const el = currentElement(action);
    el.scrollIntoView({block:'center',behavior:'instant'});
    if (action.kind === 'click') {
      if (el.matches('input[type="file"]')) throw new Error('אין תמיכה בהעלאת קבצים.');
      const link = el.closest('a[href]');
      // Open direct links in the selected tab only. Never follow javascript:, downloads or new windows.
      if (link) {
        if (link.hasAttribute('download') || !href(el) || href(el)==='[unavailable]') throw new Error('קישור זה אינו זמין להפעלה.');
        return {ok:true,navigate:href(el),message:'נבחר קישור לפתיחה בכרטיסייה הנבחרת.'};
      }
      if (el.form?.target && el.form.target !== '_self') throw new Error('טופס שפותח כרטיסייה אחרת אינו נתמך.');
      el.click(); return {ok:true,message:'נשלחה לחיצה לרכיב.'};
    }
    if (action.kind === 'type') {
      if (el.readOnly) throw new Error('השדה זמין לקריאה בלבד.');
      const allowed = el.matches('textarea,input[type="text"],input[type="search"],input[type="email"],input[type="url"],input[type="tel"],input[type="number"],input:not([type])');
      if (allowed) { el.focus(); dispatchValue(el,action.text); }
      else if (el.isContentEditable && el.getAttribute('contenteditable')==='true') {
        el.focus(); el.textContent=action.text;
        el.dispatchEvent(new InputEvent('input',{bubbles:true,inputType:'insertText',data:action.text}));
      } else throw new Error('מילוי זמין רק בשדה טקסט רגיל.');
      return {ok:true,message:'השדה מולא. לא נשלח Enter ולא נשלח טופס.'};
    }
    if (action.kind === 'select') {
      if (!(el instanceof HTMLSelectElement) || !Array.from(el.options).some(o=>o.value===action.value && !o.disabled)) throw new Error('אפשרות הבחירה אינה זמינה.');
      dispatchValue(el,action.value); return {ok:true,message:'הבחירה עודכנה.'};
    }
    throw new Error('פעולה לא נתמכת.');
  }
  globalThis.__gwbTarget = {snapshot,execute,documentKey,version:'0.2.0'};
})();
