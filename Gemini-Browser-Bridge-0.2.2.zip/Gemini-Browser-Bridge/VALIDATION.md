# Validation — 2026-10-11

Version: 0.2.2 (experimental).

## Completed

62 automated checks passed using Node.js 24.19.0. These exercise the actual JavaScript source with synthetic Chrome API/DOM environments, not a live browser:

- 13 protocol checks: exact nonce, one JSON action, replay rejection, URL policy, supported actions, limits, untrusted-page prompt construction, code fences after prose, quoted JSON with unchanged field contents, distinct format errors, array/wrapper rejection, fresh-decision correction prompts, completion-status validation and English/Hebrew browser-capability refusal detection.
- 23 service-worker checks: automatic routine actions, approval for consequential actions, one-time approval, stale-message rejection, STOP, sender/tab/frame authorization, manual fallback, missing host permission, automatic cross-origin navigation, separate Chrome host access and resuming the exact pending navigation once; bounded automatic corrections with fresh nonces, no execution of rejected replies, preserved serious-action approvals, captured diagnostic replies, correction-delivery failures, reconnection and STOP during correction. Additional cases exercise one per-task capability clarification, recovery into automatic search, repeated-refusal pause, blocked/needs-user outcomes and resumption, refusal limits surviving format recovery, manual-mode refusal handling and STOP during clarification. The next prompt receives the actually executed action with its result.
- 9 target content-script checks: sensitive-field exclusion, omission of existing field values and hidden text, controlled input/change events, stale element/page rejection, direct link navigation, select-option bounds, DOM search/non-search form metadata and changing action/form metadata before execution.
- 9 Gemini adapter checks: multiple request rounds, draft preservation, streaming completion, cancellation, nonce filtering after restoration, later answer/code fragments, delayed JSON without a stop button, one-time reporting of a non-JSON reply, and cancellation during a delayed send.
- 8 approval-policy checks: ordinary controls and fields run automatically; send/delete/publish/pay/security changes and non-search form submissions require approval; mutation URLs and icon-only metadata are detected; search markers cannot bypass explicit danger signals; risk flags cannot be supplied by the model.

Commands:

```bash
node --test tests/core.test.js tests/runtime.test.js tests/target.test.js tests/gemini.test.js tests/policy.test.js
node --check background.js
node --check core.js
node --check reply-parser.js
node --check gemini.js
node --check panel.js
node --check target.js
```

## Not verified

- Full Chromium extension integration and UI rendering. The prepared Playwright suite could not run: no Chromium binary was installed, and attempts to fetch it returned an invalid/empty archive. `tests/browser.test.cjs` is included for running with an available Chromium installation.
- Live Gemini selectors, site prompt acceptance, rendering of model responses, and model compliance with the JSON protocol.
- Browser's real optional-host permission dialog and whether all user-gesture paths are accepted.
- Real Windows execution of the optional PowerShell extraction script.
- Third-party website event handling, effectiveness of consequential-action heuristics on arbitrary sites, model quality, and behavior under actual browser throttling, worker suspension or Google usage limits.

No live Gemini request was used to validate this extension. Automated extension checks use synthetic tabs and DOMs. Publishing the downloadable ZIP uses the authorized GitHub account and is separate from extension validation.

For first use, test a harmless read-only task, then an ordinary search field. Routine actions execute automatically; detected consequential actions pause for one-time approval. A successful simulated test is not evidence that a particular live website works or that hidden JavaScript effects are always identified.
