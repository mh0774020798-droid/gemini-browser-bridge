// Shared by the worker's ES module and the isolated Gemini content script.
// Parse data only: never evaluate code, repair an ID, or select between conflicting commands.
(() => {
  const version='0.2.1';
  if (globalThis.__gwbReplyParser?.version===version) return;
  function formatError(code,message) {
    const error=new Error(`${message} לא בוצעה פעולה.`);
    error.code=code; error.replyRecoverable=true; return error;
  }
  function decode(text) {
    let value=JSON.parse(text);
    // A copied code block is sometimes quoted as a JSON string. Decode once, without altering values.
    if (typeof value==='string') value=JSON.parse(value);
    return value;
  }
  function scan(text) {
    const values=[];
    try { return {values:[decode(text.trim())],incomplete:false}; } catch {}
    let start=-1, stack=[], inString=false, escaped=false;
    for (let i=0;i<text.length;i++) {
      const ch=text[i];
      if (start<0) {
        if (ch==='{' || ch==='[') { start=i; stack=[ch]; inString=false; escaped=false; }
        continue;
      }
      if (inString) {
        if (escaped) escaped=false;
        else if (ch==='\\') escaped=true;
        else if (ch==='"') inString=false;
      } else if (ch==='"') inString=true;
      else if (ch==='{' || ch==='[') stack.push(ch);
      else if (ch==='}' || ch===']') {
        if (stack.at(-1)!==(ch==='}'?'{':'[')) { start=-1; stack=[]; continue; }
        stack.pop();
        if (!stack.length) {
          try { values.push(decode(text.slice(start,i+1))); } catch {}
          start=-1;
        }
      }
    }
    return {values,incomplete:start>=0};
  }
  function inspect(text) {
    if (typeof text!=='string' || !text.trim() || text.length>40000) {
      throw formatError('REPLY_SIZE','התשובה ריקה או ארוכה מדי.');
    }
    const values=[]; let incomplete=false,position=0;
    // Read complete fences separately so an unmatched brace in preceding prose cannot hide the answer.
    const fences=/```(?:[a-zA-Z0-9_-]+)?[ \t]*\r?\n([\s\S]*?)```/g;
    for (const match of text.matchAll(fences)) {
      for (const part of [text.slice(position,match.index),match[1]]) {
        const result=scan(part); values.push(...result.values); incomplete ||= result.incomplete;
      }
      position=match.index+match[0].length;
    }
    const tail=scan(text.slice(position)); values.push(...tail.values); incomplete ||= tail.incomplete;
    return {values,incomplete};
  }
  function readEnvelope(text,expectedRequestId) {
    const {values,incomplete}=inspect(text);
    const objects=values.filter(value=>value && typeof value==='object' && !Array.isArray(value));
    const matches=objects.filter(value=>value.protocol==='gwb/1' && value.requestId===expectedRequestId);
    if (matches.length>1) throw formatError('REPLY_AMBIGUOUS','בתשובה יש יותר מהוראה אחת לבקשה הנוכחית.');
    if (matches.length===1) return matches[0];
    if (objects.some(value=>value.protocol==='gwb/1')) {
      throw formatError('REPLY_ID','מזהה הבקשה בתשובת Gemini חסר או שייך לבקשה אחרת.');
    }
    if (objects.some(value=>value.requestId===expectedRequestId)) {
      throw formatError('REPLY_PROTOCOL','שדה protocol חסר או שונה מ־gwb/1.');
    }
    if (values.some(Array.isArray)) throw formatError('REPLY_ARRAY','Gemini החזיר רשימה; נדרשת הוראה אחת כאובייקט JSON.');
    throw formatError(incomplete?'REPLY_INCOMPLETE':'REPLY_MISSING',incomplete?
      'תשובת ה־JSON עדיין אינה שלמה.':'לא נמצא JSON תקין בתשובת Gemini.');
  }
  globalThis.__gwbReplyParser={version,readEnvelope,inspect,formatError};
})();
