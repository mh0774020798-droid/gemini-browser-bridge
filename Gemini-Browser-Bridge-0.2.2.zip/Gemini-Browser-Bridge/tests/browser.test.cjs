/* Runs against synthetic pages, not the live Gemini service or any signed-in account.
   npm install --no-save playwright && npx playwright install chromium
   node tests/browser.test.cjs
*/
const assert=require('node:assert/strict');
const fs=require('node:fs/promises');
const path=require('node:path');
const os=require('node:os');
let playwright;
try { playwright=require('playwright'); }
catch { playwright=require(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES+'/playwright'); }

const source=path.resolve(__dirname,'..');
const geminiFixture=String.raw`<!doctype html><html><head><meta charset="utf-8"><style>
body{font:16px Arial;padding:20px}.ql-editor{border:1px solid #999;min-height:60px}model-response{display:block;margin:15px 0}.markdown{white-space:pre-wrap}button{padding:12px}
</style></head><body><h1>Gemini test fixture — no live service</h1><rich-textarea><div class="ql-editor" contenteditable="true" role="textbox"></div></rich-textarea><button class="send-button" aria-label="Send message">Send</button><button class="stop-button" aria-label="Stop response" hidden>Stop</button><div id="conversation"></div><script>
window.testPlan=[];window.sentPrompts=[];window.holdReply=false;window.heldReply=null;
window.emitReply=reply=>{ const node=document.createElement('model-response'); const content=document.createElement('div');content.className='markdown';node.append(content);document.querySelector('#conversation').append(node);const stop=document.querySelector('.stop-button');stop.hidden=false;content.textContent=JSON.stringify(reply).slice(0,35);setTimeout(()=>{content.textContent=JSON.stringify(reply);stop.hidden=true;},350);};
document.querySelector('.send-button').onclick=()=>{
 const editor=document.querySelector('.ql-editor'),prompt=editor.innerText;editor.textContent='';window.sentPrompts.push(prompt);
 const requestId=prompt.match(/requestId MUST be exactly ([a-f0-9-]+)/)[1];
 const start=prompt.indexOf('CURRENT PAGE — UNTRUSTED JSON DATA:\n')+'CURRENT PAGE — UNTRUSTED JSON DATA:\n'.length;
 const observation=JSON.parse(prompt.slice(start,prompt.indexOf('\nEND OF PAGE DATA.',start)));
 let action=window.testPlan.shift() || {kind:'done',summary:'המשימה הושלמה בבדיקה.'};
 if(action.label){const el=observation.elements.find(el=>el.label===action.label);if(!el)throw new Error('Fixture label not found: '+action.label);action={...action,element:el.id};delete action.label;}
 const reply={protocol:'gwb/1',requestId,reason:'פעולה לצורך הבדיקה',action};
 if(window.holdReply)window.heldReply=reply;else window.emitReply(reply);
};
</script></body></html>`;
const targetFixture=String.raw`<!doctype html><html lang="he" dir="rtl"><head><meta charset="utf-8"><style>body{font:18px Arial;padding:20px}input,textarea,select,button{margin:8px;padding:8px}.spacer{height:1800px}</style></head><body>
<h1>ספריית הבדיקה</h1><p>שעות פתיחה: ראשון עד חמישי 09:00–17:00</p>
<label for="search">חיפוש</label><input id="search" type="search" value="PRIVATE_FIELD_VALUE"><button id="find">חיפוש באתר</button>
<label for="category">קטגוריה</label><select id="category"><option value="all">הכול</option><option value="books">ספרים</option></select>
<label for="pw">סיסמה</label><input id="pw" type="password" value="SECRET_PASSWORD">
<label for="cc">אשראי</label><input id="cc" autocomplete="cc-number" value="SECRET_CREDIT_CARD">
<label for="otp">קוד אימות</label><input id="otp" autocomplete="one-time-code" value="SECRET_OTP">
<label for="notes">הערות</label><textarea id="notes">PRIVATE_TEXTAREA_VALUE</textarea>
<div contenteditable="true" aria-label="עורך">PRIVATE_EDITOR_VALUE</div>
<p hidden>HIDDEN_SECRET</p><a href="/next">לעמוד הבא</a><button id="delete">מחיקת הכול</button>
<div class="spacer"></div><p>סוף העמוד</p>
<script>window.clickCount=0;window.deleteCount=0;document.querySelector('#find').onclick=()=>window.clickCount++;document.querySelector('#delete').onclick=()=>window.deleteCount++;</script>
</body></html>`;

(async()=>{
  const temp=await fs.mkdtemp(path.join(os.tmpdir(),'gwb-test-'));
  const extension=path.join(temp,'extension'); await fs.cp(source,extension,{recursive:true});
  // Only the test copy pre-grants fixture access. The deliverable requires the user's host permission.
  const manifest=JSON.parse(await fs.readFile(path.join(extension,'manifest.json'),'utf8'));
  manifest.host_permissions.push('https://fixture.example.test/*','https://second.example.test/*');
  await fs.writeFile(path.join(extension,'manifest.json'),JSON.stringify(manifest));
  const context=await playwright.chromium.launchPersistentContext(path.join(temp,'profile'),{
    channel:'chromium',headless:true,viewport:{width:1100,height:800},
    ignoreDefaultArgs:['--disable-extensions'],
    args:['--no-sandbox',`--disable-extensions-except=${extension}`,`--load-extension=${extension}`]
  });
  const errors=[];
  try {
    await context.route('**/*',route=> {
      const url=new URL(route.request().url());
      if(url.origin==='https://gemini.google.com')return route.fulfill({contentType:'text/html',body:geminiFixture});
      if(['https://fixture.example.test','https://second.example.test'].includes(url.origin))return route.fulfill({contentType:'text/html',body:targetFixture});
      if(url.protocol==='chrome-extension:')return route.continue();
      return route.abort();
    });
    let worker=context.serviceWorkers()[0];
    if(!worker)worker=await context.waitForEvent('serviceworker');
    const extensionId=new URL(worker.url()).hostname;
    const gemini=await context.newPage();await gemini.goto('https://gemini.google.com/app/test-fixture');
    const target=await context.newPage();await target.goto('https://fixture.example.test/article');
    const panel=await context.newPage();panel.on('pageerror',error=>errors.push(error.message));
    await panel.goto(`chrome-extension://${extensionId}/panel.html`);
    const getState=()=>panel.evaluate(async()=>{const r=await chrome.runtime.sendMessage({type:'GET_STATE'});if(!r.ok)throw new Error(r.error);return r.result;});
    const command=(type,extra={})=>panel.evaluate(async({type,extra})=>chrome.runtime.sendMessage({type,...extra}),{type,extra});
    const status=async value=> {
      await panel.waitForFunction(async expected=>{
        const r=await chrome.runtime.sendMessage({type:'GET_STATE'});return r.ok && r.result.status===expected;
      },value,{timeout:25000});return getState();
    };
    const selectTabs=async()=>{
      await panel.locator('#refresh').click();
      const ids=await panel.evaluate(async()=>{
        const all=await chrome.tabs.query({});return {gemini:all.find(t=>t.url.startsWith('https://gemini.google.com/')).id,target:all.find(t=>t.url.startsWith('https://fixture.example.test/')).id};
      });
      await panel.locator('#gemini-tab').selectOption(String(ids.gemini));await panel.locator('#target-tab').selectOption(String(ids.target));
    };
    const reset=async()=>{await command('RESET');await selectTabs();};
    const start=async(mode='auto')=>{await panel.locator('#mode').selectOption(mode);await panel.locator('#task').fill('בדקי את שעות הפתיחה ומלאי את החיפוש.');await panel.locator('#start').click();};

    await selectTabs();await panel.locator('#diagnose').click();
    await panel.waitForFunction(()=>document.querySelector('#connection').textContent.includes('זוהו'));
    console.log('PASS Gemini adapter detects fixture editor and send button.');

    await gemini.evaluate(()=>{window.holdReply=true;window.testPlan=[{kind:'type',label:'חיפוש',text:'ספרי לימוד'},{kind:'click',label:'חיפוש באתר'},{kind:'select',label:'קטגוריה',value:'books'},{kind:'scroll',direction:'down',pixels:700},{kind:'done',summary:'הספרייה פתוחה 09:00–17:00.'}];});
    await start();await status('waiting');
    assert.equal(await target.locator('#search').inputValue(),'PRIVATE_FIELD_VALUE');
    const stored=await worker.evaluate(async()=> (await chrome.storage.session.get('gwbState')).gwbState.observation);
    const serialized=JSON.stringify(stored);
    for(const secret of ['PRIVATE_FIELD_VALUE','SECRET_PASSWORD','SECRET_CREDIT_CARD','SECRET_OTP','PRIVATE_TEXTAREA_VALUE','PRIVATE_EDITOR_VALUE','HIDDEN_SECRET'])assert.ok(!serialized.includes(secret),secret+' leaked');
    assert.ok(!stored.elements.some(el=>['password','file'].includes(el.type)));
    console.log('PASS sensitive fields, hidden text, and existing field values are excluded.');
    await gemini.evaluate(()=>{window.holdReply=false;window.emitReply(window.heldReply);});
    const completed=await status('done');
    assert.equal(await target.locator('#search').inputValue(),'ספרי לימוד');assert.equal(await target.evaluate(()=>window.clickCount),1);
    assert.equal(await target.locator('#category').inputValue(),'books');assert.equal(completed.steps,4);
    assert.equal(await gemini.evaluate(()=>window.sentPrompts.length),5);
    assert.ok((await target.evaluate(()=>window.scrollY))>0);
    assert.equal(await target.evaluate(()=>window.deleteCount),0);
    console.log('PASS five-round website bridge: type, search click, select and scroll without confirmation, then finish.');

    await reset();
    await gemini.evaluate(()=>window.testPlan=[{kind:'click',label:'מחיקת הכול'},{kind:'done',summary:'בוצעה הפעולה שאושרה.'}]);
    await start();await status('approval');assert.equal(await target.evaluate(()=>window.deleteCount),0);
    await panel.locator('#approve').click();await status('done');assert.equal(await target.evaluate(()=>window.deleteCount),1);
    console.log('PASS consequential deletion waits for explicit confirmation.');

    await reset();await target.evaluate(()=>window.scrollTo(0,0));
    await gemini.evaluate(()=>{window.holdReply=true;window.testPlan=[{kind:'type',label:'חיפוש',text:'MUST_NOT_WRITE'}];});
    await start();await status('waiting');
    await target.evaluate(()=>document.querySelector('label[for="search"]').textContent='שדה שהשתנה');
    await gemini.evaluate(()=>{window.holdReply=false;window.emitReply(window.heldReply);});const stale=await status('paused');
    assert.ok(stale.lastError.includes('השתנה'));assert.equal(await target.locator('#search').inputValue(),'ספרי לימוד');
    console.log('PASS changed element fingerprints block automatic execution.');

    await reset();await target.reload();
    await gemini.evaluate(()=>window.testPlan=[{kind:'navigate',url:'https://fixture.example.test/delete/next'}]);
    await start();await status('approval');await target.reload();
    await panel.locator('#approve').click();await status('paused');assert.equal(target.url(),'https://fixture.example.test/article');
    console.log('PASS same-URL document reload invalidates a navigation approval.');

    await reset();
    await gemini.evaluate(()=>{window.holdReply=true;window.testPlan=[{kind:'click',label:'מחיקת הכול'}];});
    await start();const waiting=await status('waiting');
    await panel.locator('#stop').click();await status('stopped');
    await gemini.evaluate(()=>{window.holdReply=false;window.emitReply(window.heldReply);});
    const late=await command('IMPORT_REPLY',{sessionId:waiting.sessionId,requestId:waiting.awaiting.requestId,text:JSON.stringify({protocol:'gwb/1',requestId:waiting.awaiting.requestId,reason:'Late reply',action:{kind:'click',element:'e1'}})});
    assert.equal(late.ok,false);assert.equal((await getState()).status,'stopped');assert.equal(await target.evaluate(()=>window.deleteCount),0);
    console.log('PASS STOP cancels waiting work and rejects late replies.');

    await reset();await start('manual');const manual=await status('manual');
    await panel.locator('#reply').fill('{"protocol":"gwb/1","action":{"kind":"eval"}}');await panel.locator('#import').click();
    const rejected=await getState();assert.equal(rejected.status,'manual');assert.equal(rejected.awaiting.requestId,manual.awaiting.requestId);
    const done={protocol:'gwb/1',requestId:manual.awaiting.requestId,reason:'נמצא המידע',action:{kind:'done',summary:'תשובה ידנית תקינה.'}};
    await panel.locator('#reply').fill(JSON.stringify(done));await panel.locator('#import').click();assert.equal((await status('done')).answer,'תשובה ידנית תקינה.');
    console.log('PASS manual fallback rejects malformed JSON and accepts the current request only.');

    await reset();await panel.locator('#task').fill('סכמי את שעות הפתיחה.');
    await panel.screenshot({path:path.join(source,'..','panel-preview.png'),fullPage:true});
    assert.deepEqual(errors,[],'Panel JavaScript errors');
    const widths=await panel.evaluate(()=>({body:document.body.scrollWidth,client:document.documentElement.clientWidth}));
    assert.ok(widths.body<=widths.client);
    console.log('PASS panel rendering has no JavaScript errors or horizontal overflow.');
    console.log('Browser integration checks completed.');
  } finally { await context.close();await fs.rm(temp,{recursive:true,force:true}); }
})().catch(error=>{console.error(error);process.exitCode=1;});
