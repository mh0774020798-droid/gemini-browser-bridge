import test from 'node:test';
import assert from 'node:assert/strict';
import {assessAction,buildPrompt} from '../core.js';

const page=element=>({url:'https://example.test/',elements:[{id:'e1',tag:'button',label:'',context:{},...element}]});
const click={kind:'click',element:'e1'};

test('ordinary navigation, typing, select, search and UI controls execute automatically',()=>{
  for (const label of ['חיפוש באתר','חפש','הבא','פתיחת תפריט','סינון','Search','Next','Open menu','Show more']) {
    assert.equal(assessAction(click,page({label})).requiresApproval,false,label);
  }
  assert.equal(assessAction({kind:'type',element:'e1',text:'delete my search results'},page({tag:'input',label:'חיפוש'})).requiresApproval,false);
  assert.equal(assessAction({kind:'select',element:'e1',value:'books'},page({tag:'select',label:'קטגוריה'})).requiresApproval,false);
  assert.equal(assessAction({kind:'navigate',url:'https://second.test/articles?q=delete'},page({})).requiresApproval,false);
});
test('sending, publishing, deletion, payments and account changes require confirmation',()=>{
  for (const label of ['שליחת הודעה','שלח','פרסום פוסט','שתף','מחיקת הכול','מחק קובץ','רכישת המוצר','שלם','תשלום','שמור הרשאות',
    'Send','Publish','Share','Delete all','Buy now','Pay now','Transfer money','Grant access','Revoke permission','Save settings','Sign in']) {
    assert.equal(assessAction(click,page({label})).requiresApproval,true,label);
  }
});
test('non-search form submission is held even when the button only says Continue',()=>{
  assert.equal(assessAction(click,page({label:'Continue',context:{submit:true,search:false}})).requiresApproval,true);
  assert.equal(assessAction(click,page({label:'Submit',context:{submit:true,search:true}})).requiresApproval,false);
  assert.equal(assessAction(click,page({label:'חיפוש',context:{submit:true,search:true}})).requiresApproval,false);
});
test('a search-form marker cannot override explicit destructive or sharing signals',()=>{
  for(const label of ['Send message','Delete account','מחיקת הכול','שלח'])assert.equal(assessAction(click,page({label,context:{submit:true,search:true}})).requiresApproval,true);
  assert.equal(assessAction(click,page({label:'Search',context:{submit:true,search:true,formAction:'https://example.test/delete'}})).requiresApproval,true);
});
test('DOM action hints catch unlabeled/icon-only consequential buttons',()=>{
  for (const context of [{identity:'deleteAccountButton'},{intent:'publish_post'},{intent:'sendMessage'},{intent:'PATCH'},{description:'פעולה זו תבצע מחיקה'}]) {
    assert.equal(assessAction(click,page({label:'Continue',context})).requiresApproval,true);
  }
});
test('permission and billing fields require confirmation but search filters and message drafts do not',()=>{
  assert.equal(assessAction({kind:'select',element:'e1',value:'admin'},page({tag:'select',label:'Role'})).requiresApproval,true);
  assert.equal(assessAction({kind:'type',element:'e1',text:'new@example.test'},page({tag:'input',label:'Account email'})).requiresApproval,true);
  assert.equal(assessAction({kind:'select',element:'e1',value:'paid'},page({tag:'select',label:'Plan',context:{formPurpose:'billing-settings'}})).requiresApproval,true);
  assert.equal(assessAction({kind:'select',element:'e1',value:'admin'},page({tag:'select',label:'Role',context:{search:true}})).requiresApproval,false);
  assert.equal(assessAction({kind:'type',element:'e1',text:'I want to send this message'},page({tag:'textarea',label:'Message'})).requiresApproval,false);
  assert.equal(assessAction(click,page({label:'הרשאות',role:'checkbox'})).requiresApproval,true);
});
test('mutation URLs are held, including URL-encoded paths and query action parameters',()=>{
  for (const url of ['https://example.test/delete-account','https://example.test/%64elete/123','https://example.test/endpoint?action=delete',
    'https://example.test/endpoint?_method=POST','https://example.test/pay','https://example.test/send']) {
    assert.equal(assessAction({kind:'navigate',url},page({})).requiresApproval,true,url);
  }
  assert.equal(assessAction(click,page({label:'Next',href:'https://example.test/endpoint?action=delete'})).requiresApproval,true);
});
test('the prompt explicitly communicates selective approvals without delegating risk to Gemini',()=>{
  const prompt=buildPrompt({task:'חפשי מידע',requestId:'request',observation:page({}),steps:0});
  assert.match(prompt,/execute automatically/);assert.match(prompt,/approval only/);assert.match(prompt,/do not add risk flags/);
});
