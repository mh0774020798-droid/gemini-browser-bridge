// Unit-level DOM simulation; these checks do not replace the packaged Chromium integration suite.
import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import fs from 'node:fs/promises';
import {assessAction} from '../core.js';

class MockElement {
  constructor(tag,attrs={},text='') {this.tagName=tag.toUpperCase();this.attrs={...attrs};this.innerText=text;this.textContent=text;
    this.type=attrs.type || (tag==='input'?'text':'');this.id=attrs.id || '';this.name=attrs.name || '';this.labels=[];this.isConnected=true;
    this.disabled=false;this.readOnly=false;this.isContentEditable=attrs.contenteditable==='true';this.events=[];this.clicks=0;this.form=null;}
  getAttribute(name){return Object.hasOwn(this.attrs,name)?this.attrs[name]:null;}
  hasAttribute(name){return Object.hasOwn(this.attrs,name);}
  getClientRects(){return this.hasAttribute('hidden')?[]:[{width:200,height:40}];}
  matches(selector){return selector.split(',').some(s=>{
    const tag=s.trim().match(/^([a-z]+)/i)?.[1];if(tag && tag.toUpperCase()!==this.tagName)return false;
    if(s.includes(':not([type])'))return !this.hasAttribute('type');
    const attr=s.match(/\[([\w-]+)(?:="([^"]*)")?\]/);if(!attr)return true;
    return this.hasAttribute(attr[1]) && (attr[2]===undefined || this.getAttribute(attr[1])===attr[2]);
  });}
  closest(selector){let el=this;while(el){if(el.matches(selector))return el;el=el.parentElement;}return null;}
  focus(){} scrollIntoView(){} click(){this.clicks++;} dispatchEvent(event){this.events.push(event.type);}
}
class MockInput extends MockElement {constructor(attrs,value=''){super('input',attrs);this._value=value;}get value(){return this._value;}set value(value){this._value=String(value);}}
class MockTextarea extends MockElement {constructor(attrs,value=''){super('textarea',attrs,value);this._value=value;}get value(){return this._value;}set value(value){this._value=String(value);}}
class MockSelect extends MockElement {constructor(attrs,options){super('select',attrs);this.options=options;this._value=options[0]?.value;}get value(){return this._value;}set value(value){this._value=String(value);}}
class MockEvent {constructor(type,options){this.type=type;Object.assign(this,options);}}

const script=await fs.readFile(new URL('../target.js',import.meta.url),'utf8');
function page() {
  const search=new MockInput({id:'search','aria-label':'חיפוש',type:'search'},'PRIVATE_VALUE');
  const password=new MockInput({type:'password','aria-label':'Password'},'SECRET_PASSWORD');
  const card=new MockInput({autocomplete:'cc-number','aria-label':'כרטיס'},'SECRET_CARD');
  const otp=new MockInput({autocomplete:'one-time-code','aria-label':'קוד'},'SECRET_OTP');
  const notes=new MockTextarea({},'PRIVATE_TEXTAREA_VALUE');
  const editor=new MockElement('div',{contenteditable:'true'},'PRIVATE_EDITOR_VALUE');
  const button=new MockElement('button',{},'חיפוש באתר');
  const link=new MockElement('a',{href:'https://example.test/next'},'הבא');link.href='https://example.test/next';
  const unsafe=new MockElement('a',{href:'javascript:evil()'},'אסור');unsafe.href='javascript:evil()';
  const select=new MockSelect({'aria-label':'קטגוריה'},[{value:'all',label:'הכול',disabled:false},{value:'books',label:'ספרים',disabled:false}]);
  const items=[search,password,card,otp,notes,editor,button,link,unsafe,select];
  const textNodes=[{parentElement:new MockElement('p'),textContent:'שעות פעילות 09:00–17:00'},
    {parentElement:notes,textContent:'PRIVATE_TEXTAREA_VALUE'},{parentElement:editor,textContent:'PRIVATE_EDITOR_VALUE'},
    {parentElement:new MockElement('p',{hidden:''}),textContent:'HIDDEN_VALUE'}];
  const location={href:'https://example.test/'};
  const context=vm.createContext({crypto,URL,Element:MockElement,HTMLInputElement:MockInput,HTMLTextAreaElement:MockTextarea,HTMLSelectElement:MockSelect,
    Event:MockEvent,InputEvent:MockEvent,NodeFilter:{SHOW_TEXT:4},location,
    getComputedStyle:el=>({display:el.hasAttribute('hidden')?'none':'block',visibility:'visible'}),
    window:{scrollY:0,innerHeight:800,scrollBy({top}){this.scrollY+=top;}},
    document:{body:{},documentElement:{scrollHeight:2000},title:'בדיקת עמוד',querySelectorAll:()=>items,
      getElementById:id=>items.find(el=>el.id===id),createTreeWalker:()=>{
        let i=-1;return {currentNode:null,nextNode(){i++;this.currentNode=textNodes[i];return i<textNodes.length;}};
      }}
  });
  new vm.Script(script).runInContext(context);
  const api=context.__gwbTarget;
  const observation=api.snapshot();
  const execute=action=>api.execute({action,expectedDocumentKey:observation.documentKey,expectedSnapshotKey:observation.snapshotKey,expectedUrl:observation.url});
  const idFor=name=>observation.elements.find(el=>el.label===name).id;
  return {context,search,password,notes,editor,button,link,select,observation,execute,idFor,location};
}

test('target snapshot omits secrets, existing values, custom editor values and unsafe links',()=>{
  const p=page(),text=JSON.stringify(p.observation);
  for(const forbidden of ['SECRET_PASSWORD','SECRET_CARD','SECRET_OTP','PRIVATE_VALUE','PRIVATE_TEXTAREA_VALUE','PRIVATE_EDITOR_VALUE','HIDDEN_VALUE','javascript:'])assert.ok(!text.includes(forbidden),forbidden);
  assert.ok(p.observation.text.includes('09:00–17:00'));
  assert.ok(!p.observation.elements.some(el=>el.type==='password'));
});
test('target fills a field with native value semantics, emits input/change, and never submits',()=>{
  const p=page();p.execute({kind:'type',element:p.idFor('חיפוש'),text:'ספרים'});
  assert.equal(p.search.value,'ספרים');assert.deepEqual(p.search.events,['input','change']);assert.equal(p.button.clicks,0);
});
test('target rejects an element whose label or field sensitivity changed after observation',()=>{
  const p=page(),id=p.idFor('חיפוש');p.search.attrs['aria-label']='אחר';
  assert.throws(()=>p.execute({kind:'type',element:id,text:'MUST_NOT_WRITE'}));assert.equal(p.search.value,'PRIVATE_VALUE');
  const q=page();q.search.type='password';assert.throws(()=>q.execute({kind:'type',element:q.idFor('חיפוש'),text:'MUST_NOT_WRITE'}));
});
test('target rejects replaced page context and unknown IDs',()=>{
  const p=page();p.location.href='https://example.test/new';
  assert.throws(()=>p.execute({kind:'click',element:p.idFor('חיפוש באתר')}));assert.equal(p.button.clicks,0);
  const q=page();assert.throws(()=>q.execute({kind:'click',element:'e999'}));
  assert.throws(()=>q.context.__gwbTarget.execute({action:{kind:'scroll',direction:'down',pixels:700},expectedDocumentKey:'different',expectedSnapshotKey:q.observation.snapshotKey,expectedUrl:q.observation.url}));
});
test('target returns a direct safe-link navigation instead of opening another window',()=>{
  const p=page(),result=p.execute({kind:'click',element:p.idFor('הבא')});
  assert.equal(result.navigate,'https://example.test/next');assert.equal(p.link.clicks,0);
});
test('target allows available select options and rejects unavailable values',()=>{
  const p=page();p.execute({kind:'select',element:p.idFor('קטגוריה'),value:'books'});assert.equal(p.select.value,'books');
  assert.throws(()=>p.execute({kind:'select',element:p.idFor('קטגוריה'),value:'missing'}));
});

test('actual target snapshots identify search submissions and ordinary non-search submissions distinctly',()=>{
  const p=page();
  p.button.form=new MockElement('form',{id:'search-form',role:'search',action:'/search',method:'GET'});p.button.type='submit';
  let observation=p.context.__gwbTarget.snapshot();let record=observation.elements.find(el=>el.label==='חיפוש באתר');
  assert.equal(record.context.submit,true);assert.equal(record.context.search,true);
  assert.equal(assessAction({kind:'click',element:record.id},observation).requiresApproval,false);
  p.button.form=new MockElement('form',{id:'contact-form',action:'/contact',method:'POST'});p.button.innerText='Continue';
  observation=p.context.__gwbTarget.snapshot();record=observation.elements.find(el=>el.label==='Continue');
  assert.equal(record.context.submit,true);assert.equal(record.context.search,false);
  assert.equal(assessAction({kind:'click',element:record.id},observation).requiresApproval,true);
});

test('changing an action hint after an ordinary snapshot blocks automatic execution',()=>{
  const p=page();p.button.attrs['data-action']='deleteAccount';
  assert.throws(()=>p.execute({kind:'click',element:p.idFor('חיפוש באתר')}));assert.equal(p.button.clicks,0);
});

test('changing a form destination after an ordinary snapshot blocks automatic submission',()=>{
  const p=page();p.button.form=new MockElement('form',{action:'/delete',method:'POST'});p.button.type='submit';
  assert.throws(()=>p.execute({kind:'click',element:p.idFor('חיפוש באתר')}));assert.equal(p.button.clicks,0);
});
