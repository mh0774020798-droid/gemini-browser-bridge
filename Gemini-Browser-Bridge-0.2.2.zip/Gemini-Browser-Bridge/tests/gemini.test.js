// Tests the actual content-script state machine with a simulated DOM and clock.
import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import fs from 'node:fs/promises';
const source=await fs.readFile(new URL('../gemini.js',import.meta.url),'utf8');
const parserSource=await fs.readFile(new URL('../reply-parser.js',import.meta.url),'utf8');

function harness() {
  let listener,clock=1000,nextInterval=0,onReply=null,onSend=null,holdPauses=false;
  const pauses=[];
  const intervals=new Map(),messages=[],responses=[];
  const node=text=>({innerText:text,hidden:false,disabled:false,
    getClientRects(){return this.hidden?[]:[{}];},getAttribute(){return null;},
    blocks:[],querySelector(){return this.blocks[0] || null;},querySelectorAll(){return this.blocks;},
    contains(other){return this===other || this.blocks.some(block=>block.contains(other));},focus(){},dispatchEvent(){}});
  const editor=node('');Object.defineProperty(editor,'textContent',{set(value){this.innerText=value;},get(){return this.innerText;}});
  const send=node('Send');send.click=()=>onSend?.();
  const stop=node('Stop');stop.hidden=true;
  class Textarea {constructor(){this.value='';}}
  class InputEvent {constructor(type,options){this.type=type;Object.assign(this,options);}}
  const context=vm.createContext({HTMLTextAreaElement:Textarea,InputEvent,
    Date:{now:()=>clock},getComputedStyle:()=>({visibility:'visible'}),getSelection:()=>({removeAllRanges(){},addRange(){}}),
    setInterval:fn=>{const id=++nextInterval;intervals.set(id,fn);return id;},clearInterval:id=>intervals.delete(id),
    setTimeout:fn=>{if(holdPauses)pauses.push(fn);else fn();return 1;},
    document:{querySelectorAll(selector){
      if(selector.includes('model-response'))return responses;
      if(selector.includes('rich-textarea') || selector.includes('.ql-editor'))return [editor];
      if(selector.includes('send-button'))return [send];
      if(selector.includes('stop-button') || selector==='button[aria-label]')return [stop];
      return [];
    },createElement:()=>new Textarea(),createRange:()=>({selectNodeContents(){}}),
    execCommand(_command,_ui,text){editor.innerText=text;return true;}},
    chrome:{runtime:{id:'extension',onMessage:{addListener(fn){listener=fn;}},async sendMessage(message){messages.push(message);if(message.type==='GEMINI_REPLY' && onReply)return onReply(message);return {ok:true};}}}
  });
  new vm.Script(parserSource).runInContext(context);
  new vm.Script(source).runInContext(context);
  const dispatch=message=>new Promise(resolve=>listener(message,{id:'extension'},resolve));
  const emit=text=>{const result=node(text);responses.push(result);return result;};
  const tick=async ms=>{clock+=ms;for(const fn of Array.from(intervals.values()))await fn();};
  return {editor,send,stop,messages,responses,dispatch,emit,tick,node,
    setReply(fn){onReply=fn;},setSend(fn){onSend=fn;},intervals,
    holdPauses(){holdPauses=true;},releasePauses(){holdPauses=false;for(const fn of pauses.splice(0))fn();}};
}
const request=(id)=>({type:'GEMINI_SEND',sessionId:'session',requestId:id,prompt:'Prompt '+id,adapter:{}});
const reply=id=>JSON.stringify({protocol:'gwb/1',requestId:id,reason:'בדיקה',action:{kind:'done',summary:'תשובה'}});

test('Gemini adapter releases a response before the worker requests the next prompt',async()=>{
  const h=harness();let sendNumber=0;
  h.setSend(()=>{h.editor.innerText='';h.emit(reply(++sendNumber===1?'one':'two'));});
  h.setReply(async message=>{
    if(message.requestId==='one')assert.equal((await h.dispatch(request('two'))).ok,true);
    return {ok:true};
  });
  assert.equal((await h.dispatch(request('one'))).ok,true);
  await h.tick(100);await h.tick(1900);await h.tick(100);await h.tick(1900);await h.tick(3000);
  const replies=h.messages.filter(m=>m.type==='GEMINI_REPLY');
  assert.equal(replies.length,2);assert.deepEqual(replies.map(m=>m.requestId),['one','two']);
});
test('Gemini adapter never overwrites a user draft and does not send while generation is active',async()=>{
  const h=harness();h.editor.innerText='טיוטה אישית';
  assert.equal((await h.dispatch(request('one'))).ok,false);assert.equal(h.editor.innerText,'טיוטה אישית');
  h.editor.innerText='';h.stop.hidden=false;
  assert.equal((await h.dispatch(request('one'))).ok,false);assert.equal(h.editor.innerText,'');
});
test('Gemini adapter waits for a stable finished response, including streamed partial text',async()=>{
  const h=harness();let response;
  h.setSend(()=>{h.editor.innerText='';response=h.emit('{partial');h.stop.hidden=false;});
  await h.dispatch(request('one'));await h.tick(100);await h.tick(3000);
  assert.equal(h.messages.filter(m=>m.type==='GEMINI_REPLY').length,0);
  response.innerText=reply('one');h.stop.hidden=true;await h.tick(100);await h.tick(1500);
  assert.equal(h.messages.filter(m=>m.type==='GEMINI_REPLY').length,0);
  await h.tick(400);assert.equal(h.messages.filter(m=>m.type==='GEMINI_REPLY').length,1);
});
test('Gemini adapter cancel ignores a late model response',async()=>{
  const h=harness();h.setSend(()=>{h.editor.innerText='';});
  await h.dispatch(request('one'));await h.dispatch({type:'GEMINI_CANCEL'});h.emit('one');
  await h.tick(5000);assert.equal(h.intervals.size,0);assert.equal(h.messages.filter(m=>m.type==='GEMINI_REPLY').length,0);
});
test('restored Gemini watcher ignores model replies that do not contain the current request ID',async()=>{
  const h=harness();h.emit('old unrelated model reply');
  await h.dispatch({type:'GEMINI_WATCH',sessionId:'session',requestId:'current',adapter:{}});
  await h.tick(100);await h.tick(3000);assert.equal(h.messages.filter(m=>m.type==='GEMINI_REPLY').length,0);
  h.emit(reply('current'));await h.tick(100);await h.tick(1900);
  assert.equal(h.messages.filter(m=>m.type==='GEMINI_REPLY').length,1);
});
test('Gemini adapter reads JSON in a later markdown fragment and a separate code block',async()=>{
  const h=harness();const wrapper=h.node('whole response');
  const prose=h.node('הנה הפעולה הבאה');const code=h.node(reply('one'));
  // querySelector would return only prose; querySelectorAll returns every rendered answer fragment.
  wrapper.blocks=[prose,code];
  h.setSend(()=>{h.editor.innerText='';h.responses.push(wrapper);});
  await h.dispatch(request('one'));await h.tick(100);await h.tick(1900);
  const received=h.messages.find(m=>m.type==='GEMINI_REPLY');
  assert.ok(received);assert.match(received.text,/"requestId":"one"/);assert.match(received.text,/הנה הפעולה/);
});
test('Gemini adapter waits for delayed JSON even when the site exposes no stop button',async()=>{
  const h=harness();let response;
  h.setSend(()=>{h.editor.innerText='';response=h.emit('הפעולה היא:');});
  await h.dispatch(request('one'));await h.tick(3000);
  assert.equal(h.messages.filter(m=>m.type==='GEMINI_REPLY').length,0);
  response.innerText+='\n'+reply('one').slice(0,80);await h.tick(100);await h.tick(8000);
  assert.equal(h.messages.filter(m=>m.type==='GEMINI_REPLY').length,0);
  response.innerText='הפעולה היא:\n'+reply('one');await h.tick(100);await h.tick(1900);
  assert.equal(h.messages.filter(m=>m.type==='GEMINI_REPLY').length,1);
});
test('Gemini adapter reports a finished non-JSON reply once so the worker can request correction',async()=>{
  const h=harness();h.setSend(()=>{h.editor.innerText='';h.emit('אין לי גישה לדפדפן.');});
  await h.dispatch(request('one'));await h.tick(3000);
  assert.equal(h.messages.filter(m=>m.type==='GEMINI_REPLY').length,0);
  await h.tick(4100);await h.tick(30000);
  assert.equal(h.messages.filter(m=>m.type==='GEMINI_REPLY').length,1);assert.equal(h.intervals.size,0);
});
test('STOP during a delayed send prevents the Gemini send button from being clicked',async()=>{
  const h=harness();let clicks=0;h.send.disabled=true;h.holdPauses();h.setSend(()=>clicks++);
  const writing=h.dispatch(request('one'));
  await h.dispatch({type:'GEMINI_CANCEL'});h.send.disabled=false;h.releasePauses();
  assert.equal((await writing).ok,false);assert.equal(clicks,0);assert.equal(h.intervals.size,0);
});
