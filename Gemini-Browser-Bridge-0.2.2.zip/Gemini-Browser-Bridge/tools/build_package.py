"""Create the ZIP and an optional self-contained Windows PowerShell extractor."""
from pathlib import Path
import base64
import hashlib
import io
import json
import textwrap
import zipfile

source = Path(__file__).resolve().parents[1]
version = json.loads((source / 'manifest.json').read_text())['version']
archive_root = 'Gemini-Browser-Bridge'
output = source.parent
zip_path = output / f'Gemini-Browser-Bridge-{version}.zip'

buffer = io.BytesIO()
with zipfile.ZipFile(buffer, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for file in sorted(source.rglob('*')):
        relative = file.relative_to(source)
        if not file.is_file() or file.is_symlink() or any(p in {'node_modules', '.git', '__pycache__', 'dist'} for p in relative.parts):
            continue
        info = zipfile.ZipInfo(f'{archive_root}/{relative.as_posix()}', (2026, 10, 11, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o644 << 16
        archive.writestr(info, file.read_bytes())
payload = buffer.getvalue()
zip_path.write_bytes(payload)
digest = hashlib.sha256(payload).hexdigest()
encoded = '\n'.join(textwrap.wrap(base64.b64encode(payload).decode('ascii'), 100))

template = r'''#requires -Version 5.1
# Gemini Browser Bridge __VERSION__ — local extractor; no network, registry edits or automatic extension loading.
$ErrorActionPreference = 'Stop'
try {
    $taskPayload = @'
__PAYLOAD__
'@
    $taskBytes = [Convert]::FromBase64String($taskPayload)
    $taskHasher = [Security.Cryptography.SHA256]::Create()
    try { $taskHash = ([BitConverter]::ToString($taskHasher.ComputeHash($taskBytes))).Replace('-', '').ToLowerInvariant() }
    finally { $taskHasher.Dispose() }
    if ($taskHash -ne '__SHA256__') { throw 'The embedded archive failed its integrity check.' }
    if (-not $env:LOCALAPPDATA -or -not $env:TEMP) { throw 'This script is intended for Windows.' }
    $taskBase = Join-Path $env:LOCALAPPDATA 'GeminiBrowserBridge'
    $taskRun = 'v__VERSION__-' + [Guid]::NewGuid().ToString('N').Substring(0, 8)
    $taskDestination = Join-Path $taskBase $taskRun
    [IO.Directory]::CreateDirectory($taskDestination) | Out-Null
    $taskArchive = Join-Path $env:TEMP ('gwb-' + [Guid]::NewGuid().ToString('N') + '.zip')
    [IO.File]::WriteAllBytes($taskArchive, $taskBytes)
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    try { [IO.Compression.ZipFile]::ExtractToDirectory($taskArchive, $taskDestination) }
    finally { if (Test-Path -LiteralPath $taskArchive) { Remove-Item -LiteralPath $taskArchive -Force } }
    $taskExtensionFolder = Join-Path $taskDestination 'Gemini-Browser-Bridge'
    if (-not (Test-Path -LiteralPath (Join-Path $taskExtensionFolder 'manifest.json'))) { throw 'The extension folder is missing.' }
    Write-Host ''
    Write-Host 'התוסף חולץ. התיקייה לטעינה ב-Chrome:' -ForegroundColor Cyan
    Write-Host $taskExtensionFolder -ForegroundColor White
    Write-Host ''
    Write-Host 'פתחי chrome://extensions והפעילי מצב מפתח.'
    Write-Host 'לחצי Load unpacked / טעינת תוסף לא ארוז ובחרי את התיקייה הזאת.'
    Write-Host 'לאחר הטעינה, פתחי שיחה חדשה ב-Gemini ולחצי על סמל התוסף.'
    Start-Process -FilePath 'explorer.exe' -ArgumentList ('"{0}"' -f $taskExtensionFolder)
    $taskChromeCandidates = @()
    if ($env:ProgramFiles) { $taskChromeCandidates += Join-Path $env:ProgramFiles 'Google\Chrome\Application\chrome.exe' }
    if (${env:ProgramFiles(x86)}) { $taskChromeCandidates += Join-Path ${env:ProgramFiles(x86)} 'Google\Chrome\Application\chrome.exe' }
    $taskChromeCandidates += Join-Path $env:LOCALAPPDATA 'Google\Chrome\Application\chrome.exe'
    $taskChrome = $taskChromeCandidates | Where-Object { Test-Path -LiteralPath $_ } | Select-Object -First 1
    if ($taskChrome) { Start-Process -FilePath $taskChrome -ArgumentList 'chrome://extensions/' }
    Write-Host ''
    Read-Host 'לחצי Enter לסיום' | Out-Null
} catch {
    Write-Host ('Extraction failed: ' + $_.Exception.Message) -ForegroundColor Red
    exit 1
}
'''
script = template.replace('__VERSION__', version).replace('__PAYLOAD__', encoded).replace('__SHA256__', digest)
script_path = output / 'Install-Gemini-Browser-Bridge.ps1'
script_path.write_text(script, encoding='utf-8-sig')

# Verify embedded bytes and every archived runtime source, not just the ZIP directory.
extracted_payload = base64.b64decode(script.split("$taskPayload = @'\n", 1)[1].split("\n'@", 1)[0])
assert extracted_payload == payload
with zipfile.ZipFile(io.BytesIO(payload)) as archive:
    assert archive.testzip() is None
    for name in archive.namelist():
        relative = Path(name).relative_to(archive_root)
        assert archive.read(name) == (source / relative).read_bytes()
        assert '..' not in relative.parts
print(json.dumps({'zip': str(zip_path), 'zip_bytes': len(payload), 'powershell': str(script_path),
                  'powershell_bytes': script_path.stat().st_size, 'sha256': digest}, ensure_ascii=False))
